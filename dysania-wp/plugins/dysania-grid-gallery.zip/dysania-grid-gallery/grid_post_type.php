<?php	 
function dysania_grid_custom_init()
{
    $labels = array(
        'name' => __('Gallery Items', 'dysaniagrid'),
		'singular_name' => __('Gallery Item', 'dysaniagrid'),
		'add_new' => __('Add New', 'dysaniagrid'),
		'add_new_item' => __('Add New Item', 'dysaniagrid'),
		'edit_item' => __('Edit Item', 'dysaniagrid'),
		'new_item' => __('New Item', 'dysaniagrid'),
		'view_item' => __('View Item', 'dysaniagrid'),
		'search_items' => __('Search Items', 'dysaniagrid'),
		'not_found' =>  __('No items found', 'dysaniagrid'),
		'not_found_in_trash' => __('No items found in Trash', 'dysaniagrid'),
		'parent_item_colon' => '',
		'menu_name'  => __( 'Gallery Items', 'dysaniagrid' )

	  );
    
	 $args = array(
		'labels' => $labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'has_archive' => true,
		'hierarchical' => false,
        'exclude_from_search' => false,
        'show_in_nav_menus' => false,
		'menu_position' => 99,
		'menu_icon'  => 'dashicons-format-gallery',
		'supports' => array('title','thumbnail')
	  );
	  register_post_type('dysania_grid',$args);

	  $labels = array(
		'name' => __( 'Filters', 'dysaniagrid' ),
		'singular_name' => __( 'Filter', 'dysaniagrid' ),
		'search_items' =>  __( 'Search Types', 'dysaniagrid' ),
		'all_items' => __( 'All Filters', 'dysaniagrid' ),
		'parent_item' => __( 'Parent Filter', 'dysaniagrid' ),
		'parent_item_colon' => __( 'Parent Filter:', 'dysaniagrid' ),
		'edit_item' => __( 'Edit Filters', 'dysaniagrid' ),
		'update_item' => __( 'Update Filter', 'dysaniagrid' ),
		'add_new_item' => __( 'Add New Filter', 'dysaniagrid' ),
		'new_item_name' => __( 'New Filter Name', 'dysaniagrid' ),
	  );
		// Custom taxonomy
		register_taxonomy('dysaniatags',array('dysania_grid'), array(
		'hierarchical' => false,
		'labels' => $labels,
        'show_admin_column' => true,
		'show_ui' => true,
        'show_in_nav_menus' => false,    
		'query_var' => true,
		'rewrite' => array( 'slug' => 'tag-gallery' ),
	  ));
	  
	}

    $dysaniaselect_metabox = array( 
        'id' => 'dysaniaselect',
        'title' => 'Select Post Type',
        'page' => array('dysania_grid'),
        'context' => 'normal',
        'priority' => 'default',
        'fields' => array(                    
                    array(
                        'name'          => 'Post Type',
                        'desc'          => '',
                        'id'                => 'dysaniaselect',
                        'class'             => 'dysaniaselect',
                        'type'          => 'select',
                        'rich_editor'   => 0,            
                        'max'           => 0             
                    ),
                    )
    ); 

    $portfoliolink_3_metabox = array( 
        'id' => 'filterselect',
        'title' => 'Select Gallery',
        'page' => array('dysania_grid'),
        'context' => 'normal',
        'priority' => 'default',
        'fields' => array(                     
                    array(
                        'name'          => 'Select Filter',
                        'desc'          => '',
                        'id'                => 'dysania_filterselect',
                        'class'             => 'dysania_filterselect',
                        'type'          => 'select',
                        'rich_editor'   => 0,            
                        'max'           => 0             
                    ),
                    )
    ); 


    add_action('init', 'dysania_grid_custom_init');
	add_action('admin_init','dysania_portfolio_meta_init');
    add_action('admin_init','dysania_title_meta_init');
    add_action('admin_menu', 'add_dysaniaselect_meta_box');
    add_action('admin_menu', 'dysania_add_portfoliolink_3_meta_box');

	
	function dysania_title_meta_init()
	{
		add_meta_box('dysania_title_meta', 'Thumbnail Title (Optional)', 'dysania_title_meta_setup', 'dysania_grid', 'normal', 'low');
	}
	
	function dysania_title_meta_setup()
	{
		global $post;
	 	 
		?>
<div class="dysania_title_meta_control">
<p><input type="text" name="dysania_title" value="<?php echo get_post_meta($post->ID,'dysania_title',TRUE); ?>" style="width: 100%;" /></p>  
</div>	

		<?php

		echo '<input type="hidden" name="dysaniatitle_meta_noncename" value="' . wp_create_nonce(__FILE__) . '" />';
	}

    function dysania_add_portfoliolink_3_meta_box() {
     
        global $portfoliolink_3_metabox;        
     
        foreach($portfoliolink_3_metabox['page'] as $page) {
            add_meta_box($portfoliolink_3_metabox['id'], $portfoliolink_3_metabox['title'], 'dysania_show_portfoliolink_3_box', $page, 'normal', 'high', $portfoliolink_3_metabox);
        }

    }
	
	function dysania_portfolio_meta_init()
	{
		add_meta_box('dysania_portfolio_meta', 'Video URL / Link', 'dysania_portfolio_meta_setup', 'dysania_grid', 'normal', 'low');
	}
	
	function dysania_portfolio_meta_setup()
	{
		global $post;
	 	 
		?>
<div class="dysania_portfolio_meta_control">
<p><input type="text" name="dysania_video" value="<?php echo get_post_meta($post->ID,'dysania_video',TRUE); ?>" style="width: 100%;" /></p>
<label>Example embed video links;</label>
<pre>http://www.youtube.com/embed/1iIZeIy7TqM</pre>
<pre>http://player.vimeo.com/video/24535181</pre>    
</div>	

		<?php

		echo '<input type="hidden" name="dysania_meta_noncename" value="' . wp_create_nonce(__FILE__) . '" />';
	}

function add_dysaniaselect_meta_box() {
     
        global $dysaniaselect_metabox;        
     
        foreach($dysaniaselect_metabox['page'] as $page) {
            add_meta_box($dysaniaselect_metabox['id'], $dysaniaselect_metabox['title'], 'show_dysaniaselect_box', $page, 'side', 'high', $dysaniaselect_metabox);
        }

    }
 function show_dysaniaselect_box()  {
        global $post;
        global $dysaniaselect_metabox;
        echo '<input type="hidden" name="dysaniaselect_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';         
        foreach ($dysaniaselect_metabox['fields'] as $field) {
            $meta = get_post_meta($post->ID, $field['id'], true);            
            switch ($field['type']) {
                case 'select':
                    echo '<select style="width:100%;" name="', $field['id'], '" id="', $field['id'], '">
                    <option'; 
					if ($meta == 'dysania-photo') { echo ' selected="selected"'; }
                    echo ' value="dysania-photo" >Photo</option><option';
                    if ($meta == 'dysania-iframe') { echo ' selected="selected"'; }
                    echo ' value="dysania-iframe">Iframe</option><option'; 
                    if ($meta == 'dysania-link') { echo ' selected="selected"'; }
                    echo ' value="dysania-link">Link</option>'; 
                    break;
            }
            echo    '</select>';
            ?>
<script type="text/javascript">
jQuery(document).ready(function() {
    var dysaniaselect = jQuery( "#dysaniaselect option:selected").val();
    if (dysaniaselect == 'dysania-photo') {
        jQuery('#dysania_portfolio_meta').hide();
    }
    else {
        jQuery('#dysania_portfolio_meta').show();
    }
});    
jQuery(document).on('change', '#dysaniaselect', function() {
    var dysaniaselect = jQuery( "#dysaniaselect option:selected").val();
    if (dysaniaselect == 'dysania-photo') {
        jQuery('#dysania_portfolio_meta').hide();
    }
    else {
        jQuery('#dysania_portfolio_meta').show();
    }
}); 
</script> 
<?php
        }

    } 
    function dysania_show_portfoliolink_3_box()  {
        global $post;
        global $portfoliolink_3_metabox;
        global $dysania_prefix;
        global $wp_version;
        
        $args = array(
            'posts_per_page'   => 99,
            'post_type'        => 'dynasiagallery' 
        );
        $galleries = get_posts($args);
        
        echo '<input type="hidden" name="dysania_portfoliolink_3_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';         
   
        foreach ($portfoliolink_3_metabox['fields'] as $field) {
            $meta = get_post_meta($post->ID, $field['id'], true);            
            switch ($field['type']) {
                case 'select':
                echo '<select style="width:100%;" name="', $field['id'], '" id="', $field['id'], '">';
                    foreach ($galleries as $gallery) :
                    ?>
                    <option <?php if ($meta == $gallery->ID) { echo ' selected="selected"'; } ?> value="<?php echo $gallery->ID; ?>"><?php echo $gallery->post_title; ?></option>
                    <?php
                    endforeach;
                    break;
            }
            echo    '</select>';
        }
        }
function set_messages($messages) {
global $post, $post_ID;
$post_type = 'dysania_grid';

$obj = get_post_type_object($post_type);
$singular = $obj->labels->singular_name;
    
$gallerypageid = get_post_meta($post->ID, 'dysania_filterselect', true);    

$messages[$post_type] = array(
0 => '', // Unused. Messages start at index 1.
1 => sprintf( __('<h3>' . $singular.' updated. <a href="' . admin_url() . 'post.php?post='.strtolower($gallerypageid).'&action=edit">Go to Gallery &raquo;</a></h3>'), esc_url( get_permalink($post_ID) ) ),
2 => __('Gallery item updated.', 'dysaniagrid'),
3 => __('Gallery item deleted.', 'dysaniagrid'),
4 => __($singular.' updated.'),
5 => isset($_GET['revision']) ? sprintf( __($singular.' restored to revision from %s'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
6 => sprintf( __('<h3>' . $singular.' published. <a href="/wp-admin/post.php?post='.strtolower($gallerypageid).'&action=edit">Go to Gallery &raquo;</a></h3>'), esc_url( get_permalink($post_ID) ) ),
8 => sprintf( __($singular.' submitted. <a target="_blank" href="%s">Preview '.strtolower($singular).'</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
9 => sprintf( __($singular.' scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview '.strtolower($singular).'</a>'), date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
10 => sprintf( __($singular.' draft updated. <a target="_blank" href="%s">Preview '.strtolower($singular).'</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
);
return $messages;
}

add_filter('post_updated_messages', 'set_messages' );

add_action('save_post','dysania_portfolio_meta_save');

function dysania_portfolio_meta_save($post_id) 
	{
    global $dysaniaselect_metabox;
    global $portfoliolink_3_metabox;
    if (!isset($_POST['dysania_meta_noncename']) || !wp_verify_nonce($_POST['dysania_meta_noncename'], __FILE__)) {
        return $post_id;
    }
    if (!isset($_POST['dysaniatitle_meta_noncename']) || !wp_verify_nonce($_POST['dysaniatitle_meta_noncename'], __FILE__)) {
        return $post_id;
    }
    if ('post' == $_POST['post_type']) {
        if (!current_user_can('edit_post', $post_id)) {
            return $post_id;
        }
    } elseif (!current_user_can('edit_page', $post_id)) {
        return $post_id;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }
    if(isset($_POST['dysania_video'])) 
    {
        update_post_meta($post_id, 'dysania_video', $_POST['dysania_video']);
    } else 
    {
        delete_post_meta($post_id, 'dysania_video');
    }
    if(isset($_POST['dysania_title'])) 
    {
        update_post_meta($post_id, 'dysania_title', $_POST['dysania_title']);
    } else 
    {
        delete_post_meta($post_id, 'dysania_title');
    }
    foreach ($dysaniaselect_metabox['fields'] as $field) {
         
            $old = get_post_meta($post_id, $field['id'], true);
            $new = $_POST[$field['id']];
             
            if ($new && $new != $old) {
                if($field['type'] == 'date') {
                    $new = dysania_format_date($new);
                    update_post_meta($post_id, $field['id'], $new);
                } else {
                    if(is_string($new)) {
                        $new = $new;
                    } 
                    update_post_meta($post_id, $field['id'], $new);
                     
                     
                }
            } elseif ('' == $new && $old) {
                delete_post_meta($post_id, $field['id'], $old);
            }
        }   
    foreach ($portfoliolink_3_metabox['fields'] as $field) {
         
            $old = get_post_meta($post_id, $field['id'], true);
            $new = $_POST[$field['id']];
             
            if ($new && $new != $old) {
                if($field['type'] == 'date') {
                    $new = dysania_format_date($new);
                    update_post_meta($post_id, $field['id'], $new);
                } else {
                    if(is_string($new)) {
                        $new = $new;
                    } 
                    update_post_meta($post_id, $field['id'], $new);
                     
                     
                }
            } elseif ('' == $new && $old) {
                delete_post_meta($post_id, $field['id'], $old);
            }
        }
 
}
add_action('do_meta_boxes', 'dysania_portfolio_box');

function dysania_portfolio_box() {

	remove_meta_box( 'postimagediv', 'dysania_grid', 'side' );

	add_meta_box('postimagediv', __('Item Image', 'dysaniagrid'), 'post_thumbnail_meta_box', 'dysania_grid', 'normal', 'high');

}
?>