<?php
$filterfont = get_option('dysania_gridgallery_filterfont');
$thumbnailfont = get_option('dysania_gridgallery_thumbnailfont');
$filtertoppadding = get_option('dysania_gridgallery_filtertoppadding');
$filterpadding = get_option('dysania_gridgallery_filterpadding');
$filterleft = get_option('dysania_gridgallery_filterleft');
$verticalpadding = get_option('dysania_gridgallery_verticalpadding');
$horizontalpadding = get_option('dysania_gridgallery_horizontalpadding');
$filterbottom = get_option('dysania_gridgallery_filterbottom');
$firstcolor = get_option('dysania_gridgallery_first_color');
$secondcolor = get_option('dysania_gridgallery_second_color');
$thirdcolor = get_option('dysania_gridgallery_third_color');
$fourthcolor = get_option('dysania_gridgallery_fourth_color');
$defaultimage = get_option('dysania_gridgallery_defaultimage');
$duration = get_option('dysania_gridgallery_duration');
$zoom = get_option('dysania_gridgallery_zoom');
$rotate = get_option('dysania_gridgallery_rotate');
$opacity = get_option('dysania_gridgallery_opacity');
$disabledopacity = get_option('dysania_gridgallery_disabledopacity');
$photoicon = get_option('dysania_gridgallery_photoicon');
$iframeicon = get_option('dysania_gridgallery_iframeicon');
$linkicon = get_option('dysania_gridgallery_linkicon');
?>

<style type="text/css">
.dysania-filters {
    background-color:<?php if (!empty($firstcolor)) { echo $firstcolor; } else { echo '#1b1b1b'; } ?>;
    margin-bottom:<?php if (!empty($filterbottom)) { echo $filterbottom; } else { echo '20'; } ?>px;
    padding-bottom: <?php if (!empty($filterpadding)) { echo $filterpadding; } else { echo '15'; } ?>px;
}
.dysania-filters li {
    padding:<?php if (!empty($filtertoppadding)) { echo $filtertoppadding; } else { echo '15'; } ?>px 0px 0px <?php if (!empty($filterleft)) { echo $filterleft; } else { echo '15'; } ?>px;
}
.dysania-filters li a {
    padding:<?php if (!empty($verticalpadding)) { echo $verticalpadding; } else { echo '5'; } ?>px <?php if (!empty($horizontalpadding)) { echo $horizontalpadding; } else { echo '10'; } ?>px <?php if (!empty($verticalpadding)) { echo $verticalpadding; } else { echo '5'; } ?>px <?php if (!empty($horizontalpadding)) { echo $horizontalpadding; } else { echo '10'; } ?>px;
    font-size:<?php if (!empty($filterfont)) { echo $filterfont; } else { echo '16'; } ?>px;    
}    
.dysania-filters li a {
    color:<?php if (!empty($fourthcolor)) { echo $fourthcolor; } else { echo '#ffffff'; } ?>;
}
.dysania-filters li a:hover {
    background-color:<?php if (!empty($thirdcolor)) { echo $thirdcolor; } else { echo '#262626'; } ?>;
}
.dysania-filters li a.active, .dysania-grid li a {
    background-color:<?php if (!empty($secondcolor)) { echo $secondcolor; } else { echo '#da2f10'; } ?>;
}
.dysania-grid li .dysaniacaption {
    font-size:<?php if (!empty($thumbnailfont)) { echo $thumbnailfont; } else { echo '14'; } ?>px;  
}    
.dysania-grid li a div span {
    color:<?php if (!empty($fourthcolor)) { echo $fourthcolor; } else { echo '#ffffff'; } ?>;
    border-bottom:1px solid <?php if (!empty($secondcolor)) { echo $secondcolor; } else { echo '#da2f10'; } ?>;
    border-top:1px solid <?php if (!empty($thirdcolor)) { echo $thirdcolor; } else { echo '#262626'; } ?>;
}
.dysania-grid li a img {
    -webkit-transition: all .<?php if (!empty($duration)) { echo $duration; } else { echo '4'; } ?>s ease-in-out;
    -moz-transition: all .<?php if (!empty($duration)) { echo $duration; } else { echo '4'; } ?>s ease-in-out;
    -o-transition: all .<?php if (!empty($duration)) { echo $duration; } else { echo '4'; } ?>s ease-in-out;
    transition: all .<?php if (!empty($duration)) { echo $duration; } else { echo '4'; } ?>s ease-in-out;
} 
.dysania-grid li a img:hover {
    opacity:<?php if (!empty($opacity)) { echo $opacity; } else { echo '0.1'; } ?>;
    transform: scale(1.<?php if (!empty($zoom)) { echo $zoom; } else { echo '5'; } ?>) rotate(<?php if (!empty($rotate)) { echo $rotate; } else { echo '15'; } ?>deg);
    -webkit-transform: scale(1.<?php if (!empty($zoom)) { echo $zoom; } else { echo '5'; } ?>) rotate(<?php if (!empty($rotate)) { echo $rotate; } else { echo '15'; } ?>deg);
    -ms-transform: scale(1.<?php if (!empty($zoom)) { echo $zoom; } else { echo '5'; } ?>) rotate(<?php if (!empty($rotate)) { echo $rotate; } else { echo '15'; } ?>deg);
} 
.dysania-grid li a.dysania-photo {
    background-image:url('<?php if (!empty($photoicon)) { echo $photoicon; } else { echo plugin_dir_url( __FILE__ ) . 'css/images/zoom.png'; } ?>');
}
.dysania-grid li a.dysania-iframe {
    background-image:url('<?php if (!empty($iframeicon)) { echo $iframeicon; } else { echo plugin_dir_url( __FILE__ ) . 'css/images/iframe.png'; } ?>');
}
.dysania-grid li a.dysania-link {
    background-image:url('<?php if (!empty($linkicon)) { echo $linkicon; } else { echo plugin_dir_url( __FILE__ ) . 'css/images/link.png'; } ?>');
}
.dysania-grid li.no-effect{
    opacity:<?php if (!empty($disabledopacity)) { echo $disabledopacity; } else { echo '0.3'; } ?>;
}
.dysania-grid li .dysaniacaption {
    background-color:<?php if (!empty($firstcolor)) { echo $firstcolor; } else { echo '#1b1b1b'; } ?>;
    color:<?php if (!empty($fourthcolor)) { echo $fourthcolor; } else { echo '#ffffff'; } ?>;
}
</style>