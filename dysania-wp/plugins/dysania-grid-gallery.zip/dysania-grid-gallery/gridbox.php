<?php
add_filter("the_content", "the_dysania_content_filter");

function the_dysania_content_filter($content) {
 
	// array of custom shortcodes requiring the fix 
	$block = join("|",array("filters","filter","gridgallery"));
 
	// opening tag
	$rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
		
	// closing tag
	$rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
 
	return $rep;
 
}

function filters($atts, $content = null) {
    extract(shortcode_atts(array(
		"galleryid" => 'galleryid'
	), $atts));
    if (empty($galleryid)) {
            return '<ul id="singlefilter" class="dysania-filters"><li><a data-filter="all" class="active">' . __('All', 'dysaniagrid') . '</a></li>'.do_shortcode($content).'</ul><script type="text/javascript">jQuery(document).ready(function(){jQuery("#singlefilter").dysaniagrid({galleryid:".dysania-grid"});});</script><div class="clear"></div>';
        }
        else
        {
            return '<ul id="galleryid' . $galleryid . '" class="dysania-filters"><li><a data-filter="all" class="active">' . __('All', 'dysaniagrid') . '</a></li>'.do_shortcode($content).'</ul><script type="text/javascript">jQuery(document).ready(function(){jQuery("#galleryid' . $galleryid . '").dysaniagrid({galleryid:"#gridbox' . $galleryid . '"});});</script><div class="clear"></div>';       
        }
}  

function filter($atts, $content = null) {
        $content2 = str_replace(' ', '-', $content);
        $content2 = html_entity_decode($content2, ENT_NOQUOTES, 'UTF-8');
        $content2 = preg_replace('/[^A-Za-z0-9\-]/', '', $content2);
        return '<li><a data-filter="'.strtolower($content2).'">'.$content.'</a></li>';
}

function gridgallery($atts) {
    ob_start();
    extract(shortcode_atts(array(
		"id" => 'id',
        "columns" => 'columns',
        "resolution" => 'resolution'
	), $atts));
                global $post;
                        $loop = new WP_Query(array('post_type' => 'dysania_grid', 'meta_key' => 'dysania_filterselect','meta_value' =>  $id ,'posts_per_page' => -1));
 ?>
			<ul id="gridbox<?php echo $id; ?>" class="dysania-grid">
				<?php if ( $loop ) : 
					 
					while ( $loop->have_posts() ) : $loop->the_post(); ?>
					
						<?php
						$terms = get_the_terms( $post->ID, 'dysaniatags' );
								
						if ( $terms && ! is_wp_error( $terms ) ) : 
							$links = array();

							foreach ( $terms as $term ) 
							{
								$links[] = $term->name;
							}
							$links = str_replace(' ', '-', $links);
                            $links = preg_replace('/[^A-Za-z0-9\-]/', '', $links);
							$tax = join( " ", $links );		
						else :	
							$tax = '';	
						endif;
						?>
						
<?php $imageurl = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ) ?>
<?php $video = esc_url( get_post_meta( get_the_id(), 'dysania_video', true ) ); ?>
<?php $thumbnailtitle = get_post_meta( get_the_id(), 'dysania_title', true ); ?>                
                
                <li class="<?php if ( $columns == 1) { echo 'onecolumn'; } else if ( $columns == 2) { echo 'twocolumns'; } else if ( $columns == 3) { echo 'threecolumns'; } else if ( $columns == 4) { echo 'fourcolumns'; } else if ( $columns == 5) { echo 'fivecolumns'; } else { echo 'fourcolumns'; } ?>" data-filter="<?php echo strtolower($tax); ?>">
                    <a <?php if ( get_post_meta( get_the_id(), 'dysaniaselect', true ) == 'dysania-link' && get_option('dysania_gridgallery_targetblank') == "true") { echo 'target="_blank"'; } ?> class="<?php echo( get_post_meta( get_the_id(), 'dysaniaselect', true ) ); ?> <?php echo 'clbx' . $id; ?>" data-title="<?php the_title(); ?>" data-rel="<?php echo ( get_post_meta( get_the_id(), 'dysaniaselect', true ) ) . 'clbx' . $id; ?>" href="<?php if (!empty($video)) { echo $video; } else { echo $imageurl; } ?>">
                        <?php 
    
    if ( has_post_thumbnail() ) { 
        
        $xsmall = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'square-image-xsmall' );
        $small = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'square-image-small' );
        $medium = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'square-image-medium' );
        $large = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'square-image-large' );
        
        if ( $resolution == '150') {
            echo '<img src="' . $xsmall['0'] . '" alt="' . get_the_title($post->ID) . '" />';  
        }
        else if ( $resolution == '300') {
            echo '<img src="' . $small['0'] . '" alt="' . get_the_title($post->ID) . '" />';                       
        }
        else if ( $resolution == '480') {
            echo '<img src="' . $medium['0'] . '" alt="' . get_the_title($post->ID) . '" />';   
        }
        else if ( $resolution == '600') {
            echo '<img src="' . $large['0'] . '" alt="' . get_the_title($post->ID) . '" />';    
        }
        else {
            echo '<img src="' . $medium['0'] . '" alt="' . get_the_title($post->ID) . '" />';   
        }
    } else { 
        if (!empty($defaultimage)) {
            echo '<img src="' . $defaultimage . '" alt="" />'; 
        }
        else {
            echo '<img src="' . plugin_dir_url( __FILE__ ) . 'css/images/default.png" alt="" />'; 
        }
    } 
                        ?>
                    </a><?php if (!empty($thumbnailtitle)) { ?><span class="dysaniacaption"><?php echo $thumbnailtitle; ?></span><?php } ?>
				</li>
                <?php endwhile; ?>
                <?php endif; ?>
                <?php $disablecolorboxnav = get_option('dysania_gridgallery_disablecolorboxnav'); ?>
                <?php $clbimagewidth = get_option('dysania_gridgallery_imagewidth'); ?>
                <?php $clbimageheight = get_option('dysania_gridgallery_imageheight'); ?>
                <?php $clbiframewidth = get_option('dysania_gridgallery_iframewidth'); ?>
                <?php $clbiframeheight = get_option('dysania_gridgallery_iframeheight'); ?>
                <?php $clbslideshow = get_option('dysania_gridgallery_slideshow'); ?>
                <?php $clbslideshowspeed = get_option('dysania_gridgallery_slideshowspeed'); ?>
                <?php $clbslideshowautostart = get_option('dysania_gridgallery_slideshowautostart'); ?>
                <script type="text/javascript">
                    jQuery(document).ready(function () {
                        jQuery(".dysania-photo.<?php echo 'clbx' . $id; ?>").colorbox({ 
                            title:function(){ return jQuery(this).data('title'); }, 
                            rel:'<?php if ($disablecolorboxnav == "true") { echo 'nofollow'; } else { echo 'dysania-photoclbx' . $id; } ?>',
                            slideshow:<?php if ($clbslideshow == "true") { echo 'true'; } else { echo 'false'; } ?>,
                            slideshowSpeed:<?php if (!empty($clbslideshowspeed)) {  echo $clbslideshowspeed; } else { echo '3'; } ?>000,
                            slideshowAuto:<?php if ($clbslideshowautostart == "true") { echo 'false'; } else { echo 'true'; } ?>,
                            maxWidth:'<?php if (!empty($clbimagewidth)) {  echo $clbimagewidth; } else { echo '95'; } ?>%', 
                            maxHeight:'<?php if (!empty($clbimageheight)) {  echo $clbimageheight; } else { echo '95'; } ?>%' 
                        });
                        jQuery(".dysania-iframe.<?php echo 'clbx' . $id; ?>").colorbox({ 
                            title:function(){ return jQuery(this).data('title'); }, 
                            rel:'<?php if ($disablecolorboxnav == "true") { echo 'nofollow'; } else { echo 'dysania-iframeclbx' . $id; } ?>',
                            iframe: true, 
                            width: "<?php if (!empty($clbiframewidth)) {  echo $clbiframewidth; } else { echo '80'; } ?>%", 
                            height: "<?php if (!empty($clbiframeheight)) {  echo $clbiframeheight; } else { echo '80'; } ?>%" });
});
                    </script>
                <?php wp_reset_postdata(); ?>
                </ul> 
    
<?php
return ob_get_clean();    
} ?>