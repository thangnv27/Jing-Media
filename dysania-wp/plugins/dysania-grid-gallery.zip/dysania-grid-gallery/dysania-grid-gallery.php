<?php
/**
 * Plugin Name: Dysania Grid Gallery
 * Plugin URI: http://codecanyon.net/item/dysania-responsive-wordpress-grid-gallery-plugin/6800733
 * Description: Dysania Grid Gallery
 * Version: 1.6
 * Author: Egemenerd
 * Author URI: http://codecanyon.net/user/egemenerd
 * License: http://codecanyon.net/licenses
 */

/*---------------------------------------------------
translation
----------------------------------------------------*/

add_action( 'init', 'dysaniagriddomain' );

function dysaniagriddomain() {
	load_plugin_textdomain( 'dysaniagrid', false, 'dysania-grid-gallery/languages' );
}
/*---------------------------------------------------
custom image sizes
----------------------------------------------------*/

add_image_size( 'square-image-xsmall', 150, 150, true);
add_image_size( 'square-image-small', 300, 300, true);
add_image_size( 'square-image-medium', 480, 480, true);
add_image_size( 'square-image-large', 600, 600, true);
add_filter('image_size_names_choose', 'dysania_gridimage_sizes');

function dysania_gridimage_sizes($gridsizes) {
    $gridaddsizes = array(
        "square-image-xsmall" => __( 'Square X-Small', 'dysaniagrid'),
        "square-image-small" => __( 'Square Small', 'dysaniagrid'),
        "square-image-medium" => __( 'Square Medium', 'dysaniagrid'),
        "square-image-large" => __( 'Square Large', 'dysaniagrid')
    );
    $gridnewsizes = array_merge($gridsizes, $gridaddsizes);
    return $gridnewsizes;
}
/*---------------------------------------------------
register grid gallery css and js files
----------------------------------------------------*/
function dysania_grid_scripts(){
    wp_enqueue_script("jquery"); 
    wp_enqueue_style('dysania_grid_style', plugin_dir_url( __FILE__ ) . 'css/style.css', true, '1.0');
    wp_register_script('colorbox',plugin_dir_url( __FILE__ ).'js/jquery.colorbox-min.js','','',true);
    wp_register_script('dysania_grid_script',plugin_dir_url( __FILE__ ).'js/grid.js','','',true);
    wp_enqueue_script('dysania_grid_script');
    wp_enqueue_script('colorbox');
    if (get_option('dysania_gridgallery_colorboxstyle') == 'classic') {
        wp_enqueue_style('dysania_grid_style1', plugin_dir_url( __FILE__ ) . 'css/classic/colorbox.css', true, '1.0');
    }
    else if (get_option('dysania_gridgallery_colorboxstyle') == 'style1') {
        wp_enqueue_style('dysania_grid_style1', plugin_dir_url( __FILE__ ) . 'css/style1/colorbox.css', true, '1.0');
    }
    else if (get_option('dysania_gridgallery_colorboxstyle') == 'style2') {
        wp_enqueue_style('dysania_grid_style1', plugin_dir_url( __FILE__ ) . 'css/style2/colorbox.css', true, '1.0');
    }
    else if (get_option('dysania_gridgallery_colorboxstyle') == 'style3') {
        wp_enqueue_style('dysania_grid_style1', plugin_dir_url( __FILE__ ) . 'css/style3/colorbox.css', true, '1.0');
    }
    else if (get_option('dysania_gridgallery_colorboxstyle') == 'style4') {
        wp_enqueue_style('dysania_grid_style1', plugin_dir_url( __FILE__ ) . 'css/style4/colorbox.css', true, '1.0');
    }
    else if (get_option('dysania_gridgallery_colorboxstyle') == 'style5') {
        wp_enqueue_style('dysania_grid_style1', plugin_dir_url( __FILE__ ) . 'css/style5/colorbox.css', true, '1.0');
    }
    else {
        wp_enqueue_style('dysania_grid_style1', plugin_dir_url( __FILE__ ) . 'css/classic/colorbox.css', true, '1.0');
    }
}
add_action('wp_enqueue_scripts','dysania_grid_scripts');

/*---------------------------------------------------
register settings
----------------------------------------------------*/

function dysania_plugin_settings_init(){
register_setting( 'theme_settings', 'theme_settings' );
wp_enqueue_style('panel_style', plugin_dir_url( __FILE__ ) . 'css/panel.css', false, '1.0');
wp_enqueue_style( 'farbtastic' );
wp_enqueue_script( 'farbtastic' );    
wp_register_script('dysania_script',plugin_dir_url( __FILE__ ).'js/shortcodes.js','','',true);
wp_enqueue_script('dysania_script');    
}
add_action( 'admin_init', 'dysania_plugin_settings_init' );

/*---------------------------------------------------
tinymce button
----------------------------------------------------*/

add_action('init', 'dysania_add_button');  
function dysania_add_button() {  
   if ( current_user_can('edit_posts') &&  current_user_can('edit_pages') )  
   {  
     add_filter('mce_external_plugins', 'dysania_add_plugin');  
     add_filter('mce_buttons_2', 'dysania_register_button');  
   }  
} 

function dysania_register_button($buttons) {
    array_push($buttons, "filters");
    return $buttons;  
}  

function dysania_add_plugin($plugin_array) {
    $plugin_array['filters'] = plugin_dir_url( __FILE__ ) .'js/shortcodes.js';
    return $plugin_array;  
}

/* ----------------------------------------------------------
Add Thumbnail and Gallery ID to the Admin List
------------------------------------------------------------- */

add_filter('manage_edit-dysania_grid_columns', 'posts_columns', 5);
add_action('manage_posts_custom_column', 'posts_custom_columns', 5, 2);
function posts_columns($defaults){
    $defaults['dysania_post_dysania_filterselect'] = __('Gallery ID', 'dysaniagrid');  
    $defaults['dysania_post_thumbs'] = __('Thumbs', 'dysaniagrid');
    return $defaults;
}
function posts_custom_columns($column_name, $post_id){
    global $post;
    if($column_name === 'dysania_post_dysania_filterselect'){
        $gid = get_post_meta($post_id, 'dysania_filterselect', true);
        echo $gid;
    }   
    if($column_name === 'dysania_post_thumbs'){
        echo '<a class="thumbhover" href="';
        echo the_permalink();
        echo '" title="view" target="_blank">';
        echo the_post_thumbnail( 'square-image-xsmall', array('class' => 'thumbborder') );
        echo '</a>';
    }    
}

add_filter( 'manage_edit-dysania_grid_sortable_columns', 'my_sortable_dysania_grid_column' );
function my_sortable_dysania_grid_column( $columns ) {
    $columns['dysania_post_dysania_filterselect'] = 'galleryid'; 
    return $columns;
}
add_action( 'pre_get_posts', 'sortable_gid_orderby' );
function sortable_gid_orderby( $query ) {
    if( ! is_admin() )
        return;
 
    $orderby = $query->get( 'orderby');
 
    if( 'galleryid' == $orderby ) {
        $query->set('meta_key','dysania_filterselect');
        $query->set('orderby','meta_value_num');
    }
}

/* ----------------------------------------------------------
Add Gallery ID to the Admin List
------------------------------------------------------------- */

add_filter('manage_edit-dynasiagallery_columns', 'posts_columns2', 5);
add_action('manage_posts_custom_column', 'posts_custom_columns2', 5, 2);
function posts_columns2($defaults2){
    $defaults2['dysania_post_id'] = __('Gallery ID', 'dysaniagrid');
    return $defaults2;
}
function posts_custom_columns2($column_name2, $id){
    if($column_name2 === 'dysania_post_id'){
        echo get_the_ID();
    }    
}

/* ----------------------------------------------------------
Add Taxonomy Filter to Admin List
------------------------------------------------------------- */

function restrict_items_by_tags() {
		global $typenow;
		$post_type = 'dysania_grid';
		$taxonomy = 'dysaniatags';
		if ($typenow == $post_type) {
			$selected = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
			$info_taxonomy = get_taxonomy($taxonomy);
			wp_dropdown_categories(array(
				'show_option_all' => __("Show All {$info_taxonomy->label}"),
				'taxonomy' => $taxonomy,
				'name' => $taxonomy,
				'orderby' => 'name',
				'selected' => $selected,
				'show_count' => true,
				'hide_empty' => true,
			));
		};
	}
	add_action('restrict_manage_posts', 'restrict_items_by_tags');

	function convert_id_to_term_in_query($query) {
		global $pagenow;
		$post_type = 'dysania_grid';
		$taxonomy = 'dysaniatags';
		$q_vars = &$query->query_vars;
		if ($pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0) {
			$term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
			$q_vars[$taxonomy] = $term->slug;
		}
	}

	add_filter('parse_query', 'convert_id_to_term_in_query');


/* ----------------------------------------------------------
Declare vars
------------------------------------------------------------- */
$pluginname = "Dysania Grid Gallery";
$pluginshortname = "dysania_gridgallery";

/* ---------------------------------------------------------
Declare options
----------------------------------------------------------- */
 
$plugin_options = array (
 
array( "name" => $pluginname." Options",
"type" => "title"),   
 
/* ---------------------------------------------------------
General
----------------------------------------------------------- */
array( "name" => __('General', 'dysaniagrid'),
"type" => "section"),
array( "type" => "open"),  
    
array( "name" => __('Default Image', 'dysaniagrid'),
"desc" => __('If you dont upload any image to a gallery item, this image will be shown.', 'dysaniagrid'),
"id" => $pluginshortname."_defaultimage",
"type" => "media",
"std" => plugin_dir_url( __FILE__ ) ."css/images/default.png"), 
    
array( "name" => __('Disabled Image Opacity', 'dysaniagrid'),
"desc" => __('Value between 0-1', 'dysaniagrid'),
"id" => $pluginshortname."_disabledopacity",
"type" => "opacityy",
"std" => ""), 
    
array( "name" => __('Open Links in a New Tab', 'dysaniagrid'),
"desc" => __('If you want to open external and internal links in a new browser tab, check this box.', 'dysaniagrid'),
"id" => $pluginshortname."_targetblank",
"type" => "checkbox",
"std" => ""),     
    
array( "type" => "close"),
    
/* ---------------------------------------------------------
Colorbox
----------------------------------------------------------- */
array( "name" => __('Colorbox', 'dysaniagrid'),
"type" => "section"),
array( "type" => "open"),
    
array( "name" => __('Disable Colorbox Navigation', 'dysaniagrid'),
"desc" => __('To disable colorbox navigation, check this box.', 'dysaniagrid'),
"id" => $pluginshortname."_disablecolorboxnav",
"type" => "checkbox",
"std" => ""),      
    
array( "name" => __('Colorbox Styles', 'dysaniagrid'),
"desc" => __('Colorbox Styles', 'dysaniagrid'),
"id" => $pluginshortname."_colorboxstyle",
"type" => "style",
"std" => ""), 

array( "name" => __('Image Max. Width', 'dysaniagrid'),
"desc" => __('Maximum width of the colorbox image (percent max=100)', 'dysaniagrid'),
"id" => $pluginshortname."_imagewidth",
"type" => "number",
"std" => "95"),
    
array( "name" => __('Image Max. Height', 'dysaniagrid'),
"desc" => __('Maximum width of the colorbox image (percent max=100)', 'dysaniagrid'),
"id" => $pluginshortname."_imageheight",
"type" => "number",
"std" => "95"),
    
array( "name" => __('Iframe Width', 'dysaniagrid'),
"desc" => __('Width of the colorbox iframe (percent max=100)', 'dysaniagrid'),
"id" => $pluginshortname."_iframewidth",
"type" => "number",
"std" => "80"),
    
array( "name" => __('Iframe Height', 'dysaniagrid'),
"desc" => __('Width of the colorbox iframe (percent max=100)', 'dysaniagrid'),
"id" => $pluginshortname."_iframeheight",
"type" => "number",
"std" => "80"),
    
array( "name" => __('Activate Slideshow', 'dysaniagrid'),
"desc" => __('To activate colorbox image slideshow feature, check this box.', 'dysaniagrid'),
"id" => $pluginshortname."_slideshow",
"type" => "checkbox",
"std" => ""),
    
array( "name" => __('Disable Slideshow Autostart', 'dysaniagrid'),
"desc" => __('If checked, the slideshow will not automatically start to play.', 'dysaniagrid'),
"id" => $pluginshortname."_slideshowautostart",
"type" => "checkbox",
"std" => ""),    
    
array( "name" => __('Slideshow Speed', 'dysaniagrid'),
"desc" => __('Speed of the slideshow (second)', 'dysaniagrid'),
"id" => $pluginshortname."_slideshowspeed",
"type" => "number",
"std" => "3"),    
    
array( "type" => "close"),    
    
/* ---------------------------------------------------------
Fonts and Alignments
----------------------------------------------------------- */  
    
array( "name" => __('Fonts and Alignments', 'dysaniagrid'),
"type" => "section"),
array( "type" => "open"),
    
array( "name" => __('Filter font size', 'dysaniagrid'),
"desc" => __('Filter font size (px)', 'dysaniagrid'),
"id" => $pluginshortname."_filterfont",
"type" => "number",
"std" => "16"),
    
array( "name" => __('Thumbnail title font size', 'dysaniagrid'),
"desc" => __('Thumbnail title font size (px)', 'dysaniagrid'),
"id" => $pluginshortname."_thumbnailfont",
"type" => "number",
"std" => "14"),    
    
array( "name" => __('Menu padding (top)', 'dysaniagrid'),
"desc" => __('Menu padding (top) (px)', 'dysaniagrid'),
"id" => $pluginshortname."_filtertoppadding",
"type" => "number",
"std" => "15"),
    
array( "name" => __('Menu padding (bottom)', 'dysaniagrid'),
"desc" => __('Menu padding (bottom) (px)', 'dysaniagrid'),
"id" => $pluginshortname."_filterpadding",
"type" => "number",
"std" => "15"),
    
array( "name" => __('Menu padding (left)', 'dysaniagrid'),
"desc" => __('Menu padding (left) (px)', 'dysaniagrid'),
"id" => $pluginshortname."_filterrightleft",
"type" => "number",
"std" => "15"),     

array( "name" => __('Filter menu margin', 'dysaniagrid'),
"desc" => __('Blank space between filter menu and thumbnails (px)', 'dysaniagrid'),
"id" => $pluginshortname."_filterbottom",
"type" => "number",
"std" => "20"),    
    
array( "name" => __('Vertical link padding', 'dysaniagrid'),
"desc" => __('Filter link vertical padding (px)', 'dysaniagrid'),
"id" => $pluginshortname."_verticalpadding",
"type" => "number",
"std" => "5"),
    
array( "name" => __('Horizontal link padding', 'dysaniagrid'),
"desc" => __('Filter link horizontal padding (px)', 'dysaniagrid'),
"id" => $pluginshortname."_horizontalpadding",
"type" => "number",
"std" => "10"),     
    
array( "type" => "close"),  
    
/* ---------------------------------------------------------
CSS3 Animations
----------------------------------------------------------- */ 
    
array( "name" => __('CSS3 Animations', 'dysaniagrid'),
"type" => "section"),
array( "type" => "open"),    
    
array( "name" => __('Duration', 'dysaniagrid'),
"desc" => __('Value between 1-9', 'dysaniagrid'),
"id" => $pluginshortname."_duration",
"type" => "number",
"std" => "4"),
    
array( "name" => __('Zoom', 'dysaniagrid'),
"desc" => __('Value between 1-9', 'dysaniagrid'),
"id" => $pluginshortname."_zoom",
"type" => "number",
"std" => "5"),
    
array( "name" => __('Rotate', 'dysaniagrid'),
"desc" => __('Value between 1-360', 'dysaniagrid'),
"id" => $pluginshortname."_rotate",
"type" => "number",
"std" => "15"),
    
array( "name" => __('Opacity', 'dysaniagrid'),
"desc" => __('Value between 0-1', 'dysaniagrid'),
"id" => $pluginshortname."_opacity",
"type" => "opacity",
"std" => ""),     
    
array( "type" => "close"),
    
/* ---------------------------------------------------------
Icons
----------------------------------------------------------- */
    
array( "name" => __('Icons', 'dysaniagrid'),
"type" => "section"),
array( "type" => "open"),
    
array( "name" => __('Photo', 'dysaniagrid'),
"desc" => "",
"id" => $pluginshortname."_photoicon",
"type" => "media",
"std" => plugin_dir_url( __FILE__ ) ."css/images/zoom.png"),
    
array( "name" => __('Iframe', 'dysaniagrid'),
"desc" => "",
"id" => $pluginshortname."_iframeicon",
"type" => "media",
"std" => plugin_dir_url( __FILE__ ) ."css/images/iframe.png"),   
    
array( "name" => __('Link', 'dysaniagrid'),
"desc" => "",
"id" => $pluginshortname."_linkicon",
"type" => "media",
"std" => plugin_dir_url( __FILE__ ) ."css/images/link.png"),       
    
array( "type" => "close"),    

/* ---------------------------------------------------------
Colors
----------------------------------------------------------- */
array( "name" => __('Colors', 'dysaniagrid'),
"type" => "section"),
array( "type" => "open"),     
    
array( "name" => __('First Color', 'dysaniagrid'),
"desc" => "",
"id" => $pluginshortname."_first_color",
"type" => "text",
"std" => "#1b1b1b"), 

array( "name" => __('Second Color', 'dysaniagrid'),
"desc" => "",
"id" => $pluginshortname."_second_color",
"type" => "text",
"std" => "#da2f10"), 

array( "name" => __('Third Color', 'dysaniagrid'),
"desc" => "",
"id" => $pluginshortname."_third_color",
"type" => "text",
"std" => "#262626"), 

array( "name" => __('Fourth Color', 'dysaniagrid'),
"desc" => "",
"id" => $pluginshortname."_fourth_color",
"type" => "text",
"std" => "#ffffff"), 

array( "type" => "close")
);

/*---------------------------------------------------
Plugin Panel Output
----------------------------------------------------*/
function dysania_add_settings_page() {
add_plugins_page( __( 'Gallery Settings', 'dysaniagrid'), __( 'Gallery Settings', 'dysaniagrid'), 'manage_options', 'gallerysettings', 'dysania_plugin_settings_page');
}
add_action( 'admin_menu', 'dysania_add_settings_page' ); 

function dysania_plugin_settings_page() { 
if ( ! did_action( 'wp_enqueue_media' ) ){
    wp_enqueue_media();
}      
global $pluginname,$plugin_options;
$i=0;
$message='';
if ( 'save' == @$_REQUEST['action'] ) {

foreach ($plugin_options as $value) {
update_option( @$value['id'], @$_REQUEST[ $value['id'] ] ); }
 
if ( array_key_exists('id', $value) ) { 
foreach ($plugin_options as $value) {
if( isset( $_REQUEST[ @$value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); } else { delete_option( $value['id'] ); } }
}
$message='saved';
}
else if( 'reset' == @$_REQUEST['action'] ) {
foreach ($plugin_options as $value) {
delete_option( @$value['id'] ); }
$message='reset';
}
 
if ( $message=='saved' ) echo '<div id="message" class="updated"><p><strong>'.$pluginname.' settings saved.</strong></p></div>';
if ( $message=='reset' ) echo '<div id="message" class="updated"><p><strong>'.$pluginname.' settings reset.</strong></p></div>';
 
?>
<script type="text/javascript">
jQuery(document).ready(function (){
"use strict";

jQuery('.input_title h3').click(function(){
if(jQuery(this).parent().next('.all_options').css('display')==='none')
{    
jQuery(this).removeClass('inactive');
jQuery(this).addClass('active');
 
}
else
{    
jQuery(this).removeClass('active');
jQuery(this).addClass('inactive');
}
 
jQuery(this).parent().next('.all_options').slideToggle('slow');
return false;
});
})(jQuery);	
</script>
<div id="panelwrapper">
<div class="options_wrap">
<div id="icon-options-general"></div>
<h1><?php _e( 'Dysania Grid Gallery Settings', 'dysaniagrid' )?></h1>
<script type="text/javascript">
jQuery(document).ready(function($){
 $('#pickerdysania_gridgallery_first_color').farbtastic('#colordysania_gridgallery_first_color');   
 $('#pickerdysania_gridgallery_second_color').farbtastic('#colordysania_gridgallery_second_color');
 $('#pickerdysania_gridgallery_third_color').farbtastic('#colordysania_gridgallery_third_color');
 $('#pickerdysania_gridgallery_fourth_color').farbtastic('#colordysania_gridgallery_fourth_color');
});
</script>
<ul class="doclinks">
<li><a class="button-secondary" href="http://help.wp4life.com/" target="_blank">Knowledge Base</a></li>     
<li><a class="button-secondary" href="http://codecanyon.net/user/egemenerd?ref=egemenerd" target="_blank">Visit Support</a></li>    
</ul>
<div>
<form method="post">
 
<?php foreach ($plugin_options as $value) {
 
switch ( $value['type'] ) {
 
case "open": ?>
<?php break;
 
case "close": ?>
</div>
</div><br />

<?php break;
 
case 'text': ?>
<div class="option_input">
<label for="<?php echo $value['id']; ?>">
<?php echo $value['name']; ?></label>
<input id="color<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" name="<?php echo $value['id']; ?>" value="<?php if ( get_option( $value['id'] ) != "") { echo stripslashes(get_option( $value['id'])  ); } else { echo $value['std']; } ?>" />
<small><?php echo $value['desc']; ?> <div id="picker<?php echo $value['id']; ?>"></div></small>
<div class="clearfix"></div>
</div>
<?php break;
    
case 'number': ?>
<div class="option_input">
<label for="<?php echo $value['id']; ?>">
<?php echo $value['name']; ?></label>
<input id="color<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" onkeypress="validate(event)" name="<?php echo $value['id']; ?>" value="<?php if ( get_option( $value['id'] ) != "") { echo stripslashes(get_option( $value['id'])  ); } else { echo $value['std']; } ?>" />
<small><?php echo $value['desc']; ?> <div id="picker<?php echo $value['id']; ?>"></div></small>
<script type="text/javascript">
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}    
</script>    
<div class="clearfix"></div>
</div>
<?php break;    
 
case 'textarea': ?>
<div class="option_input">
<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
<textarea name="<?php echo $value['id']; ?>" rows="" cols=""><?php if ( get_option( $value['id'] ) != "") { echo stripslashes(get_option( $value['id']) ); } else { echo $value['std']; } ?></textarea>
<small><?php echo $value['desc']; ?></small>  
<div class="clearfix"></div>
</div>
<?php break;
    
case 'info': ?>
<div class="option_input">
<div class="option_info_box"><?php echo $value['name']; ?></div>
<div class="clearfix"></div>
</div>
<?php break;    
 
case 'editor': ?>
<div class="option_input">
<?php wp_editor( stripslashes(get_option( $value['id'])), $value['id']); ?> 
<div class="clearfix"></div>
<div style="font-size:10px; color:#F00;"><?php echo $value['desc']; ?></div>
<div class="clearfix"></div>
</div>
<?php break;  
 
case "checkbox": ?>
<div class="option_input">
<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
<?php if(get_option($value['id'])){ $checked = 'checked="checked"'; }else{ $checked = "";} ?>
<input id="<?php echo $value['id']; ?>" type="checkbox" name="<?php echo $value['id']; ?>" value="true" <?php echo $checked; ?> />
<small><?php echo $value['desc']; ?></small>
<div class="clearfix"></div>
</div>
<?php break;
    
case 'style': ?>
<div class="option_input">
<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
<select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
<option value="classic" <?php if (get_option( $value['id'] ) == 'classic') { echo 'selected="selected"'; } ?>>Classic</option>     
<option value="style1" <?php if (get_option( $value['id'] ) == 'style1') { echo 'selected="selected"'; } ?>>Style 1</option>
<option value="style2" <?php if (get_option( $value['id'] ) == 'style2') { echo 'selected="selected"'; } ?>>Style 2</option>
<option value="style3" <?php if (get_option( $value['id'] ) == 'style3') { echo 'selected="selected"'; } ?>>Style 3</option>
<option value="style4" <?php if (get_option( $value['id'] ) == 'style4') { echo 'selected="selected"'; } ?>>Style 4</option>
<option value="style5" <?php if (get_option( $value['id'] ) == 'style5') { echo 'selected="selected"'; } ?>>Style 5</option>      
</select>
<small><?php echo $value['desc']; ?></small>
<div class="clearfix"></div>
</div>
<?php break;
    
case 'opacity': ?>
<div class="option_input">
<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
<select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
<option value="0" <?php if (get_option( $value['id'] ) == 0) { echo 'selected="selected"'; } ?>>0</option>     
<option value="0.1" <?php if (get_option( $value['id'] ) == '0.1') { echo 'selected="selected"'; } ?>>0.1</option>     
<option value="0.2" <?php if (get_option( $value['id'] ) == '0.2') { echo 'selected="selected"'; } ?>>0.2</option> 
<option value="0.3" <?php if (get_option( $value['id'] ) == '0.3') { echo 'selected="selected"'; } ?>>0.3</option> 
<option value="0.4" <?php if (get_option( $value['id'] ) == '0.4') { echo 'selected="selected"'; } ?>>0.4</option> 
<option value="0.5" <?php if (get_option( $value['id'] ) == '0.5') { echo 'selected="selected"'; } ?>>0.5</option> 
<option value="0.6" <?php if (get_option( $value['id'] ) == '0.6') { echo 'selected="selected"'; } ?>>0.6</option> 
<option value="0.7" <?php if (get_option( $value['id'] ) == '0.7') { echo 'selected="selected"'; } ?>>0.7</option> 
<option value="0.8" <?php if (get_option( $value['id'] ) == '0.8') { echo 'selected="selected"'; } ?>>0.8</option> 
<option value="0.9" <?php if (get_option( $value['id'] ) == '0.9') { echo 'selected="selected"'; } ?>>0.9</option> 
<option value="1" <?php if (get_option( $value['id'] ) == 1) { echo 'selected="selected"'; } ?>>1</option>     
</select>
<small><?php echo $value['desc']; ?></small>
<div class="clearfix"></div>
</div>
<?php break;
    
case 'opacityy': ?>
<div class="option_input">
<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
<select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">   
<option value="0.1" <?php if (get_option( $value['id'] ) == '0.1') { echo 'selected="selected"'; } ?>>0.1</option>     
<option value="0.2" <?php if (get_option( $value['id'] ) == '0.2') { echo 'selected="selected"'; } ?>>0.2</option> 
<option value="0.3" <?php if (get_option( $value['id'] ) == '0.3') { echo 'selected="selected"'; } ?>>0.3</option> 
<option value="0.4" <?php if (get_option( $value['id'] ) == '0.4') { echo 'selected="selected"'; } ?>>0.4</option> 
<option value="0.5" <?php if (get_option( $value['id'] ) == '0.5') { echo 'selected="selected"'; } ?>>0.5</option> 
<option value="0.6" <?php if (get_option( $value['id'] ) == '0.6') { echo 'selected="selected"'; } ?>>0.6</option> 
<option value="0.7" <?php if (get_option( $value['id'] ) == '0.7') { echo 'selected="selected"'; } ?>>0.7</option> 
<option value="0.8" <?php if (get_option( $value['id'] ) == '0.8') { echo 'selected="selected"'; } ?>>0.8</option> 
<option value="0.9" <?php if (get_option( $value['id'] ) == '0.9') { echo 'selected="selected"'; } ?>>0.9</option>   
</select>
<small><?php echo $value['desc']; ?></small>
<div class="clearfix"></div>
</div>
<?php break;      
    
case 'media': ?>
<div class="option_input">
<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
<input id="<?php echo $value['id']; ?>_image" type="text" name="<?php echo $value['id']; ?>" value="<?php if ( get_option( $value['id'] ) != "") { echo stripslashes(get_option( $value['id'])  ); } else { echo $value['std']; } ?>" /> 
<input id="<?php echo $value['id']; ?>_image_button" class="button" type="button" value="Upload Image" />
<script type="text/javascript">
jQuery(document).ready(function($){ 
    var custom_uploader; 
    $('#<?php echo $value['id']; ?>_image_button').click(function(e) { 
        e.preventDefault();
        if (custom_uploader) {
            custom_uploader.open();
            return;
        }
        custom_uploader = wp.media.frames.file_frame = wp.media({
            title: 'Choose Image',
            button: {
                text: 'Choose Image'
            },
            multiple: false
        });
        custom_uploader.on('select', function() {
            attachment = custom_uploader.state().get('selection').first().toJSON();
            $('#<?php echo $value['id']; ?>_image').val(attachment.url);
        });
        custom_uploader.open(); 
    }); 
});    
</script>    
<div class="clearfix"></div>
</div>
<?php break;      
 
case "section":
$i++; ?>
<div class="input_section">
<div class="input_title">
 
<h3><img src="<?php echo plugin_dir_url( __FILE__ );?>css/images/settings.png" alt="">&nbsp;<?php echo $value['name']; ?></h3>
<span class="submit"><input name="save<?php echo $i; ?>" type="submit" value="Save changes" class="button-primary" /></span>
<div class="clearfix"></div>
</div>
<div class="all_options">
<?php break;
 
}
}?>
<input type="hidden" name="action" value="save" class="button-primary" />
</form>
<form method="post">
<p class="submit">
<input name="reset" type="submit" value="Reset" class="button-secondary" />
<input type="hidden" name="action" value="reset" />
</p>
</form>
</div>
<div>
<p>This plugin was made by <a title="egemenerd" href="http://themeforest.net/user/egemenerd?ref=egemenerd" target="_blank" >Egemenerd</a>.</p>
</div>
</div>
</div>
<?php
}

include('gridbox.php');
include('grid_galleries.php');
include('grid_post_type.php');

/* ----------------------------------------------------------
Register Styles
------------------------------------------------------------- */

add_action('wp_head', 'dysania_styles');
function dysania_styles() {
include('styles.php');
}

/* ----------------------------------------------------------
Register Shortcodes
------------------------------------------------------------- */

add_shortcode('filters', 'filters');
add_shortcode('filter', 'filter');
add_shortcode('gridgallery', 'gridgallery');

/* ----------------------------------------------------------
Register Galleries Widget
------------------------------------------------------------- */

add_action( 'widgets_init', 'dysania_galleries_widget' );
function dysania_galleries_widget() {
	register_widget( 'dysania_galleries' );
}

class dysania_galleries extends WP_Widget {

	function dysania_galleries() {
		$widget_ops = array( 'classname' => 'dysania', 'description' => __('Dysania Galleries', 'dysaniagrid') );		
		$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'dysaniagalleries-widget' );		
		$this->WP_Widget( 'dysaniagalleries-widget', __('Galleries', 'dysaniagrid'), $widget_ops, $control_ops );
	}
	
	function widget( $args, $instance ) {
		extract( $args );
        $title = apply_filters('widget_title', $instance['title'] );
        $gallery = $instance['gallery'];
        $columns = $instance['columns'];
        $resolution = $instance['resolution'];
		$name = '[gridgallery id="' . $instance['gallery'] . '" columns="' . $instance['columns'] . '" resolution="' . $instance['resolution'] . '"]';

		echo $before_widget;
        
        if ( $title ) {
			echo $before_title . $title . $after_title;
        }
		
		if ( $name ) {
			echo do_shortcode($name);
        }
		
		echo $after_widget;
	}
	 
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['gallery'] = strip_tags( $new_instance['gallery'] );
        $instance['columns'] = strip_tags( $new_instance['columns'] );
        $instance['resolution'] = strip_tags( $new_instance['resolution'] );

		return $instance;
	}

	
	function form( $instance ) {
		$defaults = array( 'title' => __('Galleries', 'dysaniagrid'), 'name' => __('', 'dysaniagrid'));
		$instance = wp_parse_args( (array) $instance, $defaults ); 
?>
            <?php 
        global $post;
        $dgallery = new WP_Query(array('post_type' => 'dynasiagallery'));
            ?>
<p>
    <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'dysaniagrid'); ?></label>
    <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
</p>
<p>
    <label>Select Gallery:</label>
            <select name="<?php echo $this->get_field_name( 'gallery' ); ?>" id="<?php echo $this->get_field_id( 'gallery' ); ?>" style="width:100%;">
                <?php if ( $dgallery ) : while ( $dgallery->have_posts() ) : $dgallery->the_post(); ?>
                <?php $id = get_the_ID(); ?>
                <option value="<?php the_ID(); ?>" <?php if (isset($instance['gallery'])) { if ($instance['gallery'] == $id) { echo 'selected="selected"'; }} ?>><?php echo the_title(); ?></option> 
                <?php
        endwhile;
        endif;
                ?>
            </select>
</p>
<p>
    <label>Select Columns:</label>
            <select name="<?php echo $this->get_field_name( 'columns' ); ?>" id="<?php echo $this->get_field_id( 'columns' ); ?>" style="width:100%;">
                <option value="1" <?php if (isset($instance['columns'])) { if ($instance['columns'] == 1) { echo 'selected="selected"'; }} ?>>1 Column</option> 
                <option value="2" <?php if (isset($instance['columns'])) { if ($instance['columns'] == 2) { echo 'selected="selected"'; }} ?>>2 Columns</option>     
                <option value="3" <?php if (isset($instance['columns'])) { if ($instance['columns'] == 3) { echo 'selected="selected"'; }} ?>>3 Columns</option> 
                <option value="4" <?php if (isset($instance['columns'])) { if ($instance['columns'] == 4) { echo 'selected="selected"'; }} ?>>4 Columns</option> 
                <option value="5" <?php if (isset($instance['columns'])) { if ($instance['columns'] == 5) { echo 'selected="selected"'; }} ?>>5 Columns</option> 
            </select>
</p>
<p>
    <label>Select Thumbnail Resolution:</label>
            <select name="<?php echo $this->get_field_name( 'resolution' ); ?>" id="<?php echo $this->get_field_id( 'resolution' ); ?>" style="width:100%;">
                <option value="150" <?php if (isset($instance['resolution'])) { if ($instance['resolution'] == 150) { echo 'selected="selected"'; }} ?>>150x150 px</option>     
                <option value="300" <?php if (isset($instance['resolution'])) { if ($instance['resolution'] == 300) { echo 'selected="selected"'; }} ?>>300x300 px</option> 
                <option value="480" <?php if (isset($instance['resolution'])) { if ($instance['resolution'] == 480) { echo 'selected="selected"'; }} ?>>480x480 px</option> 
                <option value="600" <?php if (isset($instance['resolution'])) { if ($instance['resolution'] == 600) { echo 'selected="selected"'; }} ?>>600x600 px</option> 
            </select>
</p>
	<?php
	}
}


?>