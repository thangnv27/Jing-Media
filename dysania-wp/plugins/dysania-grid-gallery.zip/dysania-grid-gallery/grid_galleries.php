<?php
function register_dynasiagallery_posttype() {
    $labels = array(
        'name'              => __( 'Galleries', 'dysaniagrid' ),
        'singular_name'     => __( 'Gallery', 'dysaniagrid' ),
        'add_new'           => __( 'Add New Gallery', 'dysaniagrid' ),
        'add_new_item'      => __( 'Add New Gallery', 'dysaniagrid' ),
        'edit_item'         => __( 'Edit Gallery', 'dysaniagrid' ),
        'new_item'          => __( 'New Gallery', 'dysaniagrid' ),
        'view_item'         => __( 'View Gallery', 'dysaniagrid' ),
        'search_items'      => __( 'Search Galleries', 'dysaniagrid' ),
        'not_found'         => __( 'No Gallery found', 'dysaniagrid' ),
        'not_found_in_trash'=> __( 'No Gallery found in Trash', 'dysaniagrid' ),
        'parent_item_colon' => __( 'Parent Galleries:', 'dysaniagrid' ),
        'menu_name'         => __( 'Galleries', 'dysaniagrid' )
    );

    $taxonomies = array();
 
    $supports = array('title');
 
    $post_type_args = array(
        'labels'            => $labels,
        'singular_label'    => __('gallery', 'dysaniagrid'),
        'public'            => true,
        'exclude_from_search' => true,
        'show_ui'           => true,
        'publicly_queryable'=> true,
        'query_var'         => true,
        'capability_type'   => 'post',
        'has_archive'       => false,
        'hierarchical'      => false,
        'show_in_nav_menus' => false,
        'rewrite'           => array( 'slug' => 'dynasiagallery', 'with_front' => false ),
        'supports'          => $supports,
        'menu_position'     => 99,
        'menu_icon'         => 'dashicons-portfolio',
        'taxonomies'        => $taxonomies
    );
    register_post_type('dynasiagallery',$post_type_args);
}
add_action('init', 'register_dynasiagallery_posttype');


add_action('admin_init','dysania_shortcode_meta_init');
add_action('admin_init','dysania_shortcode_meta_init2');
add_action('admin_init','dysania_shortcode_meta_init3');
add_action('admin_init','dysania_shortcode_meta_init4');
	
	function dysania_shortcode_meta_init()
	{
		add_meta_box('dysania_shortcode_meta', 'Shortcode', 'dysania_shortcode_meta_setup', 'dynasiagallery', 'normal', 'low');

	}
    function dysania_shortcode_meta_init2()
	{
		add_meta_box('dysania_shortcode_meta2', 'Gallery Items', 'dysania_shortcode_meta_setup2', 'dynasiagallery', 'normal', 'low');

	} 
    function dysania_shortcode_meta_init3()
	{
		add_meta_box('dysania_shortcode_meta3', 'Select Layout', 'dysania_shortcode_meta_setup3', 'dynasiagallery', 'side', 'high');

	} 
    function dysania_shortcode_meta_init4()
	{
		add_meta_box('dysania_shortcode_meta4', 'Select Thumbnail Resolution', 'dysania_shortcode_meta_setup4', 'dynasiagallery', 'side', 'high');

	} 
	
	function dysania_shortcode_meta_setup()
	{
		global $post;
        $postid = get_the_ID();
	 	 
		?>
<div class="dysania_shortcode_meta_control">
<p>Copy paste the following shortcode to a post or a page;</p>
[gridgallery id="<?php echo $postid; ?>"<span id="clmnslct"></span><span id="clmnrsltn"></span>]  
<p><a href="http://help.wp4life.com/2014/06/16/shortcode-isnt-working/" target="_blank">Please use text mode of the text editor. For more information click here...</a></p>    
</div>	

		<?php
	}
function dysania_shortcode_meta_setup2()
	{
		global $post;
        $postid = get_the_ID();
        $loop = new WP_Query(array('post_type' => 'dysania_grid', 'meta_key' => 'dysania_filterselect','meta_value' =>  $postid ,'posts_per_page' => -1));
    
    echo '<div class="dysania_shortcode_meta_control">';
    
    if ( $loop ) :
    if ( $loop->have_posts() ) :
    echo '<ul class="galleryitems">';
    while ( $loop->have_posts() ) : $loop->the_post();
    if ( has_post_thumbnail() ) { 
        echo '<li><a class="thumbhover" href="';
        echo the_permalink();
        echo '" title="view" target="_blank">';
        the_post_thumbnail('square-image-xsmall');
        echo '</a><a class="button button-small" href="';
        echo get_edit_post_link($post->ID);
        echo '">Edit</a>';
        echo '<a class="button button-small" href="';
        echo get_delete_post_link($post->ID);
        echo '">Delete</a></li>';
    }
    else {
        echo '<li><img width="100px" height="auto" src="';
        echo plugin_dir_url( __FILE__ );
        echo 'css/images/default.png" alt="" />';
        echo '<a class="button button-small" href="';
        echo get_edit_post_link($post->ID);
        echo '">Edit</a>';
        echo '<a class="button button-small" href="';
        echo get_delete_post_link($post->ID);
        echo '">Delete</a></li>';
        
    }
    
    endwhile;
    echo '</ul>';
    else :
    echo "<p><a href='" . admin_url('post-new.php?post_type=dysania_grid') . "' class='button-secondary'>Click here to add a new item</a></p>";
    endif;
    endif;
    wp_reset_postdata();
	 	 
		?>   
</div>	

		<?php
	}
function dysania_shortcode_meta_setup3()
	{	 	 
		?>
<div class="dysania_shortcode_meta_control">
<select id="select-column" class="select-select">
<option value="1">1 Column</option>    
<option value="2">2 Columns</option>
<option value="3">3 Columns</option>       
<option value="4" selected="selected">4 Columns</option>    
<option value="5">5 Columns</option>      
</select> 
<p><a href="http://help.wp4life.com/2014/03/06/i-cant-change-screen-resolutions-and-column-numbers/" target="_blank">Click here for more information...</a></p>
<script type="text/javascript">
jQuery(document).on('change', '#select-column', function(e) {
    var result = ' columns="' + jQuery( "#select-column option:selected").val() + '"';
    jQuery('#clmnslct').html(result);
});  
</script>    
</div>	
		<?php
	}
function dysania_shortcode_meta_setup4()
	{	 	 
		?>
<div class="dysania_shortcode_meta_control">
<select id="select-resolution" class="select-select"> 
<option value="150">150x150 px</option>    
<option value="300">300x300 px</option>
<option value="480" selected="selected">480x480 px</option>      
<option value="600">600x600 px</option>      
</select>    
<script type="text/javascript">
jQuery(document).on('change', '#select-resolution', function() {
    var result2 = ' resolution="' + jQuery( "#select-resolution option:selected").val() + '"';
    jQuery('#clmnrsltn').html(result2);
}); 
</script>    
</div>	

		<?php
	}

?>