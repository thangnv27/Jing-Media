(function () {
  "use strict";
    tinymce.create('tinymce.plugins.filters', {
        init : function(ed, url) {
            ed.addButton('filters', {
                title : 'Add a filter menu',
                image : url+'/images/filters.png',
                onclick : function() {
                     ed.selection.setContent('[filters galleryid=""]<br/>[filter]filter 1[/filter]<br/>[filter]filter 2[/filter]<br/>[filter]filter 3[/filter]<br/>[/filters]<br/>');

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('filters', tinymce.plugins.filters);
})();