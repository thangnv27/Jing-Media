(function () {
  "use strict";
    tinymce.create('tinymce.plugins.divider', {
        init : function(ed, url) {
            ed.addButton('divider', {
                title : 'Add a Divider',
                image : url+'/images/divider.png',
                onclick : function() {
                     ed.selection.setContent("[divider]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('divider', tinymce.plugins.divider);
})();


(function () {
  "use strict";
    tinymce.create('tinymce.plugins.iframecode', {
        init : function(ed, url) {
            ed.addButton('iframecode', {
                title : 'Add a Flex Iframe (Example url; http://www.youtube.com/embed/MEDKbhOwtcw)',
                image : url+'/images/video.png',
                onclick : function() {
                     ed.selection.setContent("[iframecode url='']");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('iframecode', tinymce.plugins.iframecode);
})();

(function () {
  "use strict";
    tinymce.create('tinymce.plugins.zeusslider', {
        init : function(ed, url) {
            ed.addButton('zeusslider', {
                title : 'Add a Slider',
                image : url+'/images/slider.png',
                onclick : function() {
                     ed.selection.setContent("[zeuscontainer id='1' height='2.5']<br/>[zeusslide title='' imageurl='' effect='zoomIn']<br/>[zeusslide title='' imageurl='' effect='zoomIn']<br/>[zeusslide title='' imageurl='' effect='zoomIn']<br/>[/zeuscontainer]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('zeusslider', tinymce.plugins.zeusslider);
})();

(function () {
  "use strict";
    tinymce.create('tinymce.plugins.numericlist', {
        init : function(ed, url) {
            ed.addButton('numericlist', {
                title : 'Add a Numeric List',
                image : url+'/images/list.png',
                onclick : function() {
                     ed.selection.setContent("[listcontainer]<br/>[numericlist title='Title']Lorem ipsum dolor[/numericlist]<br/>[numericlist title='Title2']Lorem ipsum dolor[/numericlist]<br/>[numericlist title='Title3']Lorem ipsum dolor[/numericlist]<br/>[/listcontainer]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('numericlist', tinymce.plugins.numericlist);
})();

(function () {
  "use strict";
    tinymce.create('tinymce.plugins.dysaniaicon', {
        init : function(ed, url) {
            ed.addButton('dysaniaicon', {
                title : 'Add a Dysania Icon List (iconid 1-36)',
                image : url+'/images/icon.png',
                onclick : function() {
                     ed.selection.setContent("[iconcontainer]<br/>[dysaniaicon iconid='1' title='Title' url='']Lorem ipsum[/dysaniaicon]<br/>[dysaniaicon iconid='2' title='Title2' url='']Lorem ipsum[/dysaniaicon]<br/>[/iconcontainer]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('dysaniaicon', tinymce.plugins.dysaniaicon);
})();

(function () {
  "use strict";
    tinymce.create('tinymce.plugins.customicon', {
        init : function(ed, url) {
            ed.addButton('customicon', {
                title : 'Add a Custom Icon List',
                image : url+'/images/icon2.png',
                onclick : function() {
                     ed.selection.setContent("[iconcontainer]<br/>[customicon iconurl='http://placehold.it/64x64.png' title='Title' url='']Lorem ipsum[/customicon]<br/>[customicon iconurl='http://placehold.it/64x64.png' title='Title2' url='']Lorem ipsum[/customicon]<br/>[/iconcontainer]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('customicon', tinymce.plugins.customicon);
})();

(function () {
  "use strict";
    tinymce.create('tinymce.plugins.rotator', {
        init : function(ed, url) {
            ed.addButton('rotator', {
                title : 'Add a Rotator',
                image : url+'/images/rotator.png',
                onclick : function() {
                     ed.selection.setContent("[rotatorcontainer id='1' speed='700' interval='7000']<br/>[rotator name='' imgurl=''][/rotator]<br/>[rotator name='' imgurl=''][/rotator]<br/>[rotator name='' imgurl=''][/rotator]<br/>[/rotatorcontainer]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('rotator', tinymce.plugins.rotator);
})();

(function () {
  "use strict";
    tinymce.create('tinymce.plugins.success', {
        init : function(ed, url) {
            ed.addButton('success', {
                title : 'Add a success message',
                image : url+'/images/success.gif',
                onclick : function() {
                     ed.selection.setContent("[success][/success]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('success', tinymce.plugins.success);
})();

(function () {
  "use strict";
    tinymce.create('tinymce.plugins.warning', {
        init : function(ed, url) {
            ed.addButton('warning', {
                title : 'Add a warning message',
                image : url+'/images/warning.png',
                onclick : function() {
                     ed.selection.setContent("[warning][/warning]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('warning', tinymce.plugins.warning);
})();

(function () {
  "use strict";
    tinymce.create('tinymce.plugins.error', {
        init : function(ed, url) {
            ed.addButton('error', {
                title : 'Add an error message',
                image : url+'/images/error.png',
                onclick : function() {
                     ed.selection.setContent("[error][/error]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('error', tinymce.plugins.error);
})();


(function () {
  "use strict";
    tinymce.create('tinymce.plugins.info', {
        init : function(ed, url) {
            ed.addButton('info', {
                title : 'Add an info message',
                image : url+'/images/info.png',
                onclick : function() {
                     ed.selection.setContent("[info][/info]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('info', tinymce.plugins.info);
})();

(function () {
  "use strict";
    tinymce.create('tinymce.plugins.label', {
        init : function(ed, url) {
            ed.addButton('label', {
                title : 'Add a label',
                image : url+'/images/label.gif',
                onclick : function() {
                     ed.selection.setContent("[label][/label]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('label', tinymce.plugins.label);
})();

(function () {
  "use strict";
    tinymce.create('tinymce.plugins.fleximage', {
        init : function(ed, url) {
            ed.addButton('fleximage', {
                title : 'Add a flex image',
                image : url+'/images/image.png',
                onclick : function() {
                     ed.selection.setContent("[fleximage caption=''][/fleximage]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('fleximage', tinymce.plugins.fleximage);
})();

(function () {
  "use strict";
    tinymce.create('tinymce.plugins.accordion', {
        init : function(ed, url) {
            ed.addButton('accordion', {
                title : 'Add an Accordion',
                image : url+'/images/accordion.png',
                onclick : function() {
                     ed.selection.setContent("[accordioncontainer id='1']<br/>[accordion title='Title' imageurl=''][/accordion]<br/>[accordion title='Title2' imageurl=''][/accordion]<br/>[accordion title='Title3' imageurl=''][/accordion]<br/>[/accordioncontainer]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('accordion', tinymce.plugins.accordion);
})();

(function () {
  "use strict";
    tinymce.create('tinymce.plugins.tabgroup', {
        init : function(ed, url) {
            ed.addButton('tabgroup', {
                title : 'Add Tabs',
                image : url+'/images/tabgroup.png',
                onclick : function() {
                     ed.selection.setContent("[tabgroup id='1']<br/>[tab title='Tab 1'][/tab]<br/>[tab title='Tab 2'][/tab]<br/>[tab title='Tab 3'][/tab]<br/>[/tabgroup]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('tabgroup', tinymce.plugins.tabgroup);
})();

(function () {
  "use strict";
    tinymce.create('tinymce.plugins.contactform', {
        init : function(ed, url) {
            ed.addButton('contactform', {
                title : 'Add a contact form',
                image : url+'/images/contactform.png',
                onclick : function() {
                     ed.selection.setContent("[contactform]");

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('contactform', tinymce.plugins.contactform);
})();