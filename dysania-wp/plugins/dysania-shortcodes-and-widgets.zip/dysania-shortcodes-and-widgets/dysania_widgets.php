<?php

add_action( 'widgets_init', 'dysania_video_widget' );

function dysania_video_widget() {
	register_widget( 'dysania_video' );
}

add_action( 'widgets_init', 'dysania_flickr_widget' );

function dysania_flickr_widget() {
	register_widget( 'dysania_flickrwidget' );
}

/* ----------------------------------------------------------
Flickr widget
------------------------------------------------------------- */
class dysania_flickrwidget extends WP_Widget {

	function dysania_flickrwidget() {
		$widget_ops = array( 'classname' => 'dysaniashortcodes', 'description' => __('Flickr Feed', 'dysaniashortcodes') );
		
		$control_ops = array( 'width' => 250, 'height' => 250, 'id_base' => 'flickr-widget' );
		
		$this->WP_Widget( 'flickr-widget', __('Flickr Widget', 'dysaniashortcodes'), $widget_ops, $control_ops );
	}
	
	function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters('widget_title', $instance['title'] );
		$name = '<ul id="cbox" class="flickr-box"></ul>';
        $itemnumber = apply_filters('widget_title', $instance['itemnumber'] );
        $flickrid = apply_filters('widget_title', $instance['flickrid'] );

		echo $before_widget;
		if ( $title )
			echo $before_title . $title . $after_title;
		
		if ( $name ) {
			printf( $name );
        }
        
        if ( $flickrid ) { ?>
        
<script type="text/javascript">
jQuery(document).ready(function(){    
jQuery('#cbox').jflickrfeed({
    <?php echo 'limit:' . $itemnumber . ','; ?>
    <?php echo 'qstrings: { id: "' . $flickrid . '"},'; ?>
    itemTemplate:
	'<li>' +
		'<a class="photo" href="{{image}}" title="{{title}}">' +
			'<img src="{{image_s}}" alt="{{title}}" />' +
		'</a>' +
	'</li>'
}, function (data) {
    jQuery('#cbox a').colorbox();
});
});    
</script>
			
        <?php }

		
		echo $after_widget;
	}
	 
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
        $instance['itemnumber'] = strip_tags( $new_instance['itemnumber'] );
        $instance['flickrid'] = strip_tags( $new_instance['flickrid'] );

		return $instance;
	}

	
	function form( $instance ) {
		$defaults = array( 'title' => __('Flickr', 'dysaniashortcodes'), 'name' => '', 'itemnumber' => '8','flickrid' => '52617155@N08');
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'dysaniashortcodes'); ?></label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:95%;" />
		</p>
<p>
			<label for="<?php echo $this->get_field_id( 'itemnumber' ); ?>"><?php _e('Maximum Item Number:', 'dysaniashortcodes'); ?></label>
			<input id="<?php echo $this->get_field_id( 'itemnumber' ); ?>" name="<?php echo $this->get_field_name( 'itemnumber' ); ?>" value="<?php echo $instance['itemnumber']; ?>" style="width:95%;" />
		</p>
<p>
			<label for="<?php echo $this->get_field_id( 'flickrid' ); ?>"><?php _e('Flickr ID:', 'dysaniashortcodes'); ?></label>
			<input id="<?php echo $this->get_field_id( 'flickrid' ); ?>" name="<?php echo $this->get_field_name( 'flickrid' ); ?>" value="<?php echo $instance['flickrid']; ?>" style="width:95%;" />
		</p>

	<?php
	}
}
/* ----------------------------------------------------------
Latest Video widget
------------------------------------------------------------- */
class dysania_video extends WP_Widget {

	function dysania_video() {
		$widget_ops = array( 'classname' => 'dysaniashortcodes', 'description' => __('iframe widget', 'dysaniashortcodes') );
		
		$control_ops = array( 'width' => 250, 'height' => 250, 'id_base' => 'video-widget' );
		
		$this->WP_Widget( 'video-widget', __('Latest Video', 'dysaniashortcodes'), $widget_ops, $control_ops );
	}
	
	function widget( $args, $instance ) {
		extract( $args );

		$title = apply_filters('widget_title', $instance['title'] );
		$name = '<div class="flex-video"><iframe src="' . esc_url($instance['name']) . '"></iframe></div>';

		echo $before_widget;

		if ( $title ) {
			echo $before_title . $title . $after_title;
        }
		
		if ( $name ) {
			printf( $name );
        }
		
		echo $after_widget;
	}
	 
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['name'] = strip_tags( $new_instance['name'] );

		return $instance;
	}

	
	function form( $instance ) {
		$defaults = array( 'title' => __('Latest Video', 'dysaniashortcodes'), 'name' => '');
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'dysaniashortcodes'); ?></label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:95%;" />
		</p>
<p>Add only iframe link. For example; http://www.youtube.com/embed/MEDKbhOwtcw</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'name' ); ?>"><?php _e('Link:', 'dysaniashortcodes'); ?></label>
			<input id="<?php echo $this->get_field_id( 'name' ); ?>" name="<?php echo $this->get_field_name( 'name' ); ?>" value="<?php echo $instance['name']; ?>" style="width:95%;"/>
		</p>

	<?php
	}
}

?>