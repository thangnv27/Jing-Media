<?php		
$namefield = get_option('dysania_name_field');
$emailfield = get_option('dysania_email_field');
$messagefield = get_option('dysania_message_field');
$sendbutton = get_option('dysania_send_button');
$contactrecipient = get_option('dysania_contactform_recipient');
$contactsubject = get_option('dysania_contactform_subject');
$contactemail = get_option('dysania_contactform_email');
?>

<form id="contactForm" action="<?php echo plugin_dir_url( __FILE__ ) . 'processform.php' ?>" method="post">
    <label>
        <?php if (!empty($namefield)) { echo $namefield; } else { echo 'Name'; } ?>
    </label>
    <input type="text" name="senderName" id="senderName" maxlength="40" />
    <label>
        <?php if (!empty($emailfield)) { echo $emailfield; } else { echo 'Email'; } ?>
    </label>
    <input type="email" name="senderEmail" id="senderEmail" maxlength="50" />
    <label>
        <?php if (!empty($messagefield)) { echo $messagefield; } else { echo 'Message'; } ?>
    </label>
    <textarea name="message" id="message"></textarea>
    <input name="recipientName" id="recipientName" type="hidden" value="<?php echo $contactrecipient; ?>" />
    <input name="recipientSubject" id="recipientSubject" type="hidden" value="<?php echo $contactsubject; ?>" />
    <input name="recipientMail" id="recipientMail" type="hidden" value="<?php echo $contactemail; ?>" />
    <input type="submit" class="button" id="sendMessage" name="sendMessage" value="<?php if (!empty($sendbutton)) { echo $sendbutton; } else { echo 'Send'; } ?>" />
</form>