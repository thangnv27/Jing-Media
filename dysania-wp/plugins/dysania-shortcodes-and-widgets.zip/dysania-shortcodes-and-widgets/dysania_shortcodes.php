<?php 

    add_shortcode('iframecode', 'iframecode');
    add_shortcode('divider', 'divider');
    add_shortcode('listcontainer', 'listcontainer');
    add_shortcode('numericlist', 'numericlist');
    add_shortcode('zeuscontainer', 'zeuscontainer');
    add_shortcode('zeusslide', 'zeusslide');
    add_shortcode('iconcontainer', 'iconcontainer');
    add_shortcode('dysaniaicon', 'dysaniaicon');
    add_shortcode('customicon', 'customicon');
    add_shortcode('fleximage', 'fleximage');
    add_shortcode('accordioncontainer', 'accordioncontainer');
    add_shortcode('accordion', 'accordion' );
    add_shortcode('rotatorcontainer', 'rotatorcontainer');
    add_shortcode('rotator', 'rotator' );
    add_shortcode('success', 'success');
    add_shortcode('error', 'error');
    add_shortcode('warning', 'warning');
    add_shortcode('info', 'info');
    add_shortcode('tabgroup', 'jquery_tab_group');
    add_shortcode("contactform", "contactform");
    add_shortcode("label", "label"); 

    add_filter("the_content", "dysania_content_filter");

function dysania_content_filter($content) {
 
	// array of custom shortcodes requiring the fix 
	$block = join("|",array("iframecode","listcontainer","zeuscontainer","zeusslide","numericlist","divider","dysaniaicon","customicon","iconcontainer","rotatorcontainer","rotator","fleximage","accordion","accordioncontainer","success","error","warning","info","tabgroup","tab","label","contactform"));
 
	// opening tag
	$rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
		
	// closing tag
	$rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
 
	return $rep;
 
}

function divider() {
		return '<hr/>';
}

function iframecode($atts, $content = null) {
	extract(shortcode_atts(array(
		"url" => 'url'
	), $atts));
		return '<div class="flex-video"><iframe src="' . esc_url($url) . '"></iframe></div>';
}

function listcontainer($atts, $content = null) {
		return '<dl class="numericlist">' . do_shortcode( $content ) . '</dl>';
}

function numericlist($atts, $content = null) {
	extract(shortcode_atts(array(
		"title" => 'title'
	), $atts));
		return '<dt>' . $title . '</dt><dd>' . wp_strip_all_tags( $content ) . '</dd>';
}

function zeuscontainer($atts, $content = null) {
    extract(shortcode_atts(array(
        "id" => 'id',
		"height" => 'height'
    ), $atts));
		return '<div id="zeusslider' . $id . '"><div class="zeus-slider zeus-default zeus-innerpage">' . do_shortcode( $content ) . '<div class="clear"></div><div class="next-block"></div><div class="prev-block"></div></div></div><script type="text/javascript"> jQuery(window).load(function() { jQuery("#zeusslider' . $id . '").zeusslider({ sliderheight: ' . $height . '}); });    
</script>';
}
function zeusslide($atts, $content = null) {
	extract(shortcode_atts(array(
        "title" => 'title',
		"effect" => 'effect',
        "imageurl" => 'imageurl'
	), $atts));
    if (empty($title)) {
        return '<div class="zeus-block"><div class="zeus-slide s-100"><img src="' . esc_url($imageurl) . '" data-effect="' . $effect . '" alt=""/></div></div>';    
    }
    else {
		return '<div class="zeus-block"><div class="zeus-slide s-100"><img src="' . esc_url($imageurl) . '" data-effect="' . $effect . '" alt=""/></div><div class="zeus-info">' . $title . '</div></div>';
    }
}

function rotatorcontainer($atts, $content = null) {
    extract(shortcode_atts(array(
        "id" => 'id',
		"speed" => 'speed',
		"interval" => 'interval'
    ), $atts));
		return '<div id="cbp-qtrotator' . $id . '" class="cbp-qtrotator">' . do_shortcode( $content ) . '</div><script type="text/javascript"> jQuery(document).ready(function() { jQuery("#cbp-qtrotator' . $id . '").cbpQTRotator({ speed: ' . $speed . ', interval: ' . $interval . ' }); });</script>';
}

function rotator($atts, $content = null) {
	extract(shortcode_atts(array(
		"name" => 'name',
        'imgurl'=> 'imgurl'
	), $atts));
    if (empty($imgurl) && empty($name)) {
        return '<div class="cbp-qtcontent"><div class="cbp-blockquote">' . $content . '</div></div>';    
    }
    if (empty($imgurl)) {
        return '<div class="cbp-qtcontent"><div class="cbp-blockquote">' . $content . '<div class="cbp-footer">' . $name . '</div></div></div>';    
    }
    else 
    {
		return '<div class="cbp-qtcontent"><img src="' . esc_url($imgurl) . '" alt="" /><div class="cbp-blockquote">' . $content . '<div class="cbp-footer">' . $name . '</div></div></div>';
    }
}

function iconcontainer($atts, $content = null) {
		return '<div class="iconcontainer">' . do_shortcode( $content ) . '</div>';
}

function dysaniaicon($atts, $content = null) {
	extract(shortcode_atts(array(
        "url" => 'url',
		"iconid" => 'iconid',
		"title" => 'title'
	), $atts));
    if (empty($url)) {
        return '<div class="icon"><div class="circle"><img src="' . plugin_dir_url( __FILE__ ) .  'icons/' . $iconid . '.png" alt=""/></div><h5>'.$title.'</h5><p>'. wp_strip_all_tags($content) .'</p></div>';    
    }
    else
    {
		return '<div class="icon"><div class="circle"><a href="' . esc_url($url) . '"><img src="' . plugin_dir_url( __FILE__ ) .  'icons/' . $iconid . '.png" alt=""/></a></div><h5>' . $title . '</h5><p>' . wp_strip_all_tags($content) . '</p></div>';
    }
}

function customicon($atts, $content = null) {
	extract(shortcode_atts(array(
        "url" => 'url',
		"iconurl" => 'iconurl',
		"title" => 'title'
	), $atts));
    if (empty($url)) {
        return '<div class="icon"><div class="circle"><img src="' . esc_url($iconurl) . '" alt=""/></div><h5>' . $title . '</h5><p>' . wp_strip_all_tags($content) . '</p></div>';    
    }
    else
    {
		return '<div class="icon"><div class="circle"><a href="' . esc_url($url) . '"><img src="' . esc_url($iconurl) . '" alt=""/></a></div><h5>'.$title.'</h5><p>' . wp_strip_all_tags($content) . '</p></div>';
    }
}

function success($atts, $content = null) {
    return '<div class="success message"><span class="message-close"></span>'. $content .'</div>';
}

function warning($atts, $content = null) {
    return '<div class="warning message"><span class="message-close"></span>'. $content .'</div>';
}

function error($atts, $content = null) {
    return '<div class="error message"><span class="message-close"></span>'. $content .'</div>';
}

function info($atts, $content = null) {
    return '<div class="info message"><span class="message-close"></span>'. $content .'</div>';
}

function label($atts, $content = null) {
    return '<span class="label">'. wp_strip_all_tags($content) .'</span>';
}

function fleximage($atts, $content = null) {
	extract(shortcode_atts(array(
		"caption" => 'caption'
	), $atts));
    if (empty($caption)) {
            return '<figure class="caption-image"><div>' . $content . '</div></figure>';
    }
    else
    {
            return '<figure class="caption-image"><div>' . $content . '</div><figcaption>' . $caption . '</figcaption></figure>';         
    }
}

function accordioncontainer($atts, $content = null) {
    extract(shortcode_atts(array(
		"id" => 'id'
	), $atts));
		return '<div id="st-accordion' . $id . '" class="st-accordion"><ul>' . do_shortcode( $content ) . '</ul></div><script type="text/javascript">jQuery(document).ready(function() { jQuery("#st-accordion' . $id . '").accordion(); });</script>';
}

function accordion($atts, $content = null) {
	extract(shortcode_atts(array(
		"title" => 'title',
        "imageurl" => 'imageurl'
	), $atts));
    if (!empty($imageurl)) {
        return '<li><a href="#">' . $title . '<span class="st-arrow">Open or Close</span></a><div class="st-content"><img src="' . esc_url($imageurl) . '" alt="' . $title . '" />' . do_shortcode( $content ) . '</div></li>';    
    }
    else
    {
		return '<li><a href="#">' . $title . '<span class="st-arrow">Open or Close</span></a><div class="st-content">' . do_shortcode( $content ) . '</div></li>';
    }
}

function jquery_tab_group( $atts, $content ){
    extract(shortcode_atts(array(
		"id" => 'id'
	), $atts));
    
$GLOBALS['tab_count'] = 0;

do_shortcode( $content );

if( is_array( $GLOBALS['tabs']) ){
$int = '1';   
foreach( $GLOBALS['tabs'] as $tab ){
$tabs[] = '
    <li class="ionTabs__tab" data-target="Tab'.$int.$id.'">'.$tab['title'].'</li>
';
$panes[] = '
<div class="ionTabs__item" data-name="Tab'.$int.$id.'">
'.$tab['content'].'

</div>
';
$int++;
}
$return = "\n".'

<div class="ionTabs" id="tabs_'.$id.'" data-name="Group'.$id.'">'."\n".'
<ul class="ionTabs__head">'.implode( "\n", $tabs ).'</ul>
<div class="ionTabs__body">'."\n".' '.implode( "\n", $panes ).'

<div class="ionTabs__preloader"></div></div></div>
'."\n";
}

return $return;
}

add_shortcode( 'tab', 'jquery_tab' );

function jquery_tab( $atts, $content ){
extract(shortcode_atts(array(
'title' => 'Tab %d'
), $atts));

$x = $GLOBALS['tab_count'];
$GLOBALS['tabs'][$x] = array( 'title' => sprintf( $title, $GLOBALS['tab_count'] ), 'content' => $content );

$GLOBALS['tab_count']++;
}

function contactform($atts) {
ob_start();
	
   include('contact.php');

   $content = ob_get_clean();
   return $content;
}

?>