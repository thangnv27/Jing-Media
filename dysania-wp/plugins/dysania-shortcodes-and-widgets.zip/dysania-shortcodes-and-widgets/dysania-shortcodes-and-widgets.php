<?php
/**
 * Plugin Name: Dysania Shortcodes and Widgets
 * Plugin URI: http://themeforest.net/user/egemenerd/portfolio
 * Description: Dysania Shortcodes and Widgets
 * Version: 1.0
 * Author: Egemenerd
 * Author URI: http://themeforest.net/user/egemenerd
 * License: http://themeforest.net/licenses
 */

add_action( 'init', 'dysaniascwdomain' );

function dysaniascwdomain() {
	load_plugin_textdomain( 'dysaniashortcodes', false, 'dysania-shortcodes-and-widgets/languages' );
}

function dysania_scw_scripts(){
    wp_enqueue_style('dysaniacpt_style', plugin_dir_url( __FILE__ ) . 'css/style.css', true, '1.0');
    wp_enqueue_style('dysania_zeusslider_style', plugin_dir_url( __FILE__ ) . 'css/zeusslider.css', true, '1.0');
    wp_enqueue_style('dysania_zeusanimations_style', plugin_dir_url( __FILE__ ) . 'css/zeusanimations.css', true, '1.0');
    wp_register_script('dysaniacpt_easing',plugin_dir_url( __FILE__ ).'js/jquery.easing.1.3.js','','',true);
    wp_register_script('dysania_zeusslider',plugin_dir_url( __FILE__ ).'js/zeusslider.js','','',true);
    wp_register_script('dysaniacpt_tabs',plugin_dir_url( __FILE__ ).'js/ion.tabs.min.js','','',true);
    wp_register_script('dysaniacpt_flickr',plugin_dir_url( __FILE__ ).'js/jflickrfeed.min.js','','',true);
    wp_register_script('dysaniacpt_accordion',plugin_dir_url( __FILE__ ).'js/jquery.accordion.js','','',true);
    wp_register_script('dysaniacpt_rotator',plugin_dir_url( __FILE__ ).'js/rotator.min.js','','',true);
    wp_enqueue_script('dysaniacpt_easing');
    wp_enqueue_script('dysania_zeusslider');
    wp_enqueue_script('dysaniacpt_tabs');
    wp_enqueue_script('dysaniacpt_flickr');
    wp_enqueue_script('dysaniacpt_accordion');
    wp_enqueue_script('dysaniacpt_rotator');
}
add_action('wp_enqueue_scripts','dysania_scw_scripts');

/*---------------------------------------------------
Tinymce custom buttons
----------------------------------------------------*/

if ( ! function_exists( 'dysaniashortcodes_add_button' ) ) {
add_action('init', 'dysaniashortcodes_add_button');  
function dysaniashortcodes_add_button() {  
   if ( current_user_can('edit_posts') &&  current_user_can('edit_pages') )  
   {  
     add_filter('mce_external_plugins', 'add_plugin');  
     add_filter('mce_buttons_3', 'register_button');  
   }  
} 
}

if ( ! function_exists( 'register_button' ) ) {
function register_button($buttons) {
    array_push($buttons, "divider");
    array_push($buttons, "zeusslider");
    array_push($buttons, "numericlist");
    array_push($buttons, "iframecode");
    array_push($buttons, "dysaniaicon");
    array_push($buttons, "customicon");
    array_push($buttons, "fleximage");
    array_push($buttons, "accordion");
    array_push($buttons, "tabgroup");
    array_push($buttons, "rotator");
    array_push($buttons, "info");
    array_push($buttons, "success");
    array_push($buttons, "warning");
    array_push($buttons, "error");
    array_push($buttons, "contactform");
    array_push($buttons, "label");
    return $buttons;  
}  
}

if ( ! function_exists( 'add_plugin' ) ) {
function add_plugin($plugin_array) {
    $plugin_array['iframecode'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['zeusslider'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['numericlist'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['divider'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['dysaniaicon'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['customicon'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['fleximage'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['accordion'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['tabgroup'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['rotator'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['info'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['success'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['warning'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['error'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['contactform'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    $plugin_array['label'] = plugin_dir_url( __FILE__ ) . '/js/shortcodes.js';
    return $plugin_array;  
}
}

include('dysania_widgets.php');
include('dysania_shortcodes.php');

?>