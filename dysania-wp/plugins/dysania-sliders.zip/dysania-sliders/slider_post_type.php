<?php
function register_dysaniaslides_posttype() {
    $labels = array(
        'name'              => __( 'Zeus Slider', 'dysaniasliders' ),
        'singular_name'     => __( 'slide', 'dysaniasliders' ),
        'add_new'           => __( 'Add New Slide', 'dysaniasliders' ),
        'add_new_item'      => __( 'Add New Slide', 'dysaniasliders' ),
        'edit_item'         => __( 'Edit Slide', 'dysaniasliders' ),
        'new_item'          => __( 'New Slide', 'dysaniasliders' ),
        'view_item'         => __( 'View Slide', 'dysaniasliders' ),
        'search_items'      => __( 'Search Slides', 'dysaniasliders' ),
        'not_found'         => __( 'No slide found', 'dysaniasliders' ),
        'not_found_in_trash'=> __( 'No slide found in Trash', 'dysaniasliders' ),
        'parent_item_colon' => __( 'Parent slides:', 'dysaniasliders' ),
        'menu_name'         => __( 'Zeus Slider', 'dysaniasliders' )
    );

    $taxonomies = array();
 
    $supports = array('title','thumbnail');
 
    $post_type_args = array(
        'labels'            => $labels,
        'singular_label'    => __('slide', 'dysaniasliders'),
        'public'            => true,
        'exclude_from_search' => true,
        'show_ui'           => true,
        'publicly_queryable'=> true,
        'query_var'         => true,
        'capability_type'   => 'post',
        'has_archive'       => false,
        'hierarchical'      => false,
        'rewrite'           => array( 'slug' => 'dysaniaslides', 'with_front' => false ),
        'supports'          => $supports,
        'menu_position'     => 99,
        'menu_icon'         => 'dashicons-camera',
        'taxonomies'        => $taxonomies
    );
    register_post_type('dysaniaslides',$post_type_args);
}
add_action('init', 'register_dysaniaslides_posttype');

$dysaniatitle_metabox = array( 
    'id' => 'secondtitle',
    'title' => 'Second Title (Optional)',
    'page' => array('dysaniaslides'),
    'context' => 'normal',
    'priority' => 'default',
    'fields' => array(                     
        array(
            'name'          => 'Second Title (Optional)',
            'desc'          => '',
            'id'                => 'dysaniaslide_title',
            'class'             => 'dysaniaslide_title',
            'type'          => 'text',
            'rich_editor'   => 0,            
            'max'           => 0             
        ),
    )
);

$dysaniaslide_metabox = array( 
    'id' => 'secondimage',
    'title' => 'Second Image (Optional)',
    'page' => array('dysaniaslides'),
    'context' => 'normal',
    'priority' => 'default',
    'fields' => array(                     
        array(
            'name'          => 'Image URL',
            'desc'          => '',
            'id'                => 'dysaniaslide_url',
            'class'             => 'dysaniaslide_url',
            'type'          => 'text',
            'rich_editor'   => 0,            
            'max'           => 0             
        ),
    )
);
$slidelink_2_metabox = array( 
        'id' => 'slidelink',
        'title' => 'Link (Optional)',
        'page' => array('dysaniaslides'),
        'context' => 'normal',
        'priority' => 'default',
        'fields' => array(                     
                    array(
                        'name'          => 'URL:',
                        'desc'          => '',
                        'id'                => 'dysaniaslide_slideurl',
                        'class'             => 'dysaniaslide_slideurl',
                        'type'          => 'text',
                        'rich_editor'   => 0,            
                        'max'           => 0             
                    ),
                    )
    );
$slidelink_3_metabox = array( 
        'id' => 'videolink',
        'title' => 'Embed Video Link (If you add a video link, images will be disabled for this slide)',
        'page' => array('dysaniaslides'),
        'context' => 'normal',
        'priority' => 'default',
        'fields' => array(                     
                    array(
                        'name'          => 'URL:',
                        'desc'          => '',
                        'id'                => 'dysaniaslide_videourl',
                        'class'             => 'dysaniaslide_videourl',
                        'type'          => 'text',
                        'rich_editor'   => 0,            
                        'max'           => 0             
                    ),
                    )
    );
$dysanianimation_metabox = array( 
        'id' => 'dysanianimation',
        'title' => 'Image Animation',
        'page' => array('dysaniaslides'),
        'context' => 'normal',
        'priority' => 'default',
        'fields' => array(                    
                    array(
                        'name'          => 'Animation',
                        'desc'          => '',
                        'id'                => 'dysanianimation',
                        'class'             => 'dysanianimation',
                        'type'          => 'select',
                        'rich_editor'   => 0,            
                        'max'           => 0             
                    ),
                    )
    );
$dysanianimation2_metabox = array( 
        'id' => 'dysanianimation2',
        'title' => '2. Image Animation',
        'page' => array('dysaniaslides'),
        'context' => 'normal',
        'priority' => 'default',
        'fields' => array(                    
                    array(
                        'name'          => 'Animation',
                        'desc'          => '',
                        'id'                => 'dysanianimation2',
                        'class'             => 'dysanianimation2',
                        'type'          => 'select',
                        'rich_editor'   => 0,            
                        'max'           => 0             
                    ),
                    )
    ); 

add_action('admin_menu', 'dysania_add_dysaniatitle_meta_box');
add_action('admin_menu', 'dysania_add_dysaniaslide_meta_box'); 
add_action('do_meta_boxes', 'dysania_image_box');
add_action('admin_menu', 'dysania_add_slidelink_2_meta_box');
add_action('admin_menu', 'dysania_add_slidelink_3_meta_box');
add_action('admin_menu', 'add_dysanianimation_meta_box');
add_action('admin_menu', 'add_dysanianimation2_meta_box');

function add_dysanianimation_meta_box() {
     
        global $dysanianimation_metabox;        
     
        foreach($dysanianimation_metabox['page'] as $page) {
            add_meta_box($dysanianimation_metabox['id'], $dysanianimation_metabox['title'], 'show_dysanianimation_box', $page, 'side', 'high', $dysanianimation_metabox);
        }

    }
 function show_dysanianimation_box()  {
        global $post;
        global $dysanianimation_metabox;
        echo '<input type="hidden" name="dysanianimation_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';         
        foreach ($dysanianimation_metabox['fields'] as $field) {
            $meta = get_post_meta($post->ID, $field['id'], true);            
            switch ($field['type']) {
                case 'select':
                echo '<select style="width:100%;" name="', $field['id'], '" id="', $field['id'], '">
                <option'; 
                if ($meta == 'slideTop') { echo ' selected="selected"'; }
                echo ' value="slideTop" >slideTop</option><option';
                if ($meta == 'slideBottom') { echo ' selected="selected"'; }
                echo ' value="slideBottom">slideBottom</option><option'; 
                if ($meta == 'slideLeft') { echo ' selected="selected"'; }
                echo ' value="slideLeft">slideLeft</option><option';                
                if ($meta == 'slideRight') { echo ' selected="selected"'; }
                echo ' value="slideRight">slideRight</option><option';
                if ($meta == 'zoomOut') { echo ' selected="selected"'; }
                echo ' value="zoomOut">zoomOut</option><option';
                if ($meta == 'zoomIn') { echo ' selected="selected"'; }
                echo ' value="zoomIn">zoomIn</option><option';
                if ($meta == 'bounceInUp') { echo ' selected="selected"'; }
                echo ' value="bounceInUp">bounceInUp</option><option';
                if ($meta == 'bounceInRight') { echo ' selected="selected"'; }
                echo ' value="bounceInRight">bounceInRight</option><option';
                if ($meta == 'bounceInDown') { echo ' selected="selected"'; }
                echo ' value="bounceInDown">bounceInDown</option><option';
                if ($meta == 'bounceInLeft') { echo ' selected="selected"'; }
                echo ' value="bounceInLeft">bounceInLeft</option><option';
                if ($meta == 'pageRight') { echo ' selected="selected"'; }
                echo ' value="pageRight">pageRight</option><option';
                if ($meta == 'pageRightBack') { echo ' selected="selected"'; }
                echo ' value="pageRightBack">pageRightBack</option><option';
                if ($meta == 'pageLeft') { echo ' selected="selected"'; }
                echo ' value="pageLeft">pageLeft</option><option';
                if ($meta == 'pageLeftBack') { echo ' selected="selected"'; }
                echo ' value="pageLeftBack">pageLeftBack</option><option';
                if ($meta == 'pageBottomBack') { echo ' selected="selected"'; }
                echo ' value="pageBottomBack">pageBottomBack</option><option';
                if ($meta == 'pageTopBack') { echo ' selected="selected"'; }
                echo ' value="pageTopBack">pageTopBack</option><option';                
                if ($meta == 'tinDown') { echo ' selected="selected"'; }
                echo ' value="tinDown">tinDown</option><option';
                if ($meta == 'tinUp') { echo ' selected="selected"'; }
                echo ' value="tinUp">tinUp</option><option';
                if ($meta == 'tinRight') { echo ' selected="selected"'; }
                echo ' value="tinRight">tinRight</option><option';
                if ($meta == 'tinLeft') { echo ' selected="selected"'; }
                echo ' value="tinLeft">tinLeft</option>';
                break;
            }
            echo    '</select>';
            ?>
<?php
        }

    }

function add_dysanianimation2_meta_box() {
     
        global $dysanianimation2_metabox;        
     
        foreach($dysanianimation2_metabox['page'] as $page) {
            add_meta_box($dysanianimation2_metabox['id'], $dysanianimation2_metabox['title'], 'show_dysanianimation2_box', $page, 'side', 'high', $dysanianimation2_metabox);
        }

    }
 function show_dysanianimation2_box()  {
        global $post;
        global $dysanianimation2_metabox;
        echo '<input type="hidden" name="dysanianimation2_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';         
        foreach ($dysanianimation2_metabox['fields'] as $field) {
            $meta = get_post_meta($post->ID, $field['id'], true);            
            switch ($field['type']) {
                case 'select':
                echo '<select style="width:100%;" name="', $field['id'], '" id="', $field['id'], '">
                <option'; 
                if ($meta == 'slideTop') { echo ' selected="selected"'; }
                echo ' value="slideTop" >slideTop</option><option';
                if ($meta == 'slideBottom') { echo ' selected="selected"'; }
                echo ' value="slideBottom">slideBottom</option><option'; 
                if ($meta == 'slideLeft') { echo ' selected="selected"'; }
                echo ' value="slideLeft">slideLeft</option><option';                
                if ($meta == 'slideRight') { echo ' selected="selected"'; }
                echo ' value="slideRight">slideRight</option><option';
                if ($meta == 'zoomOut') { echo ' selected="selected"'; }
                echo ' value="zoomOut">zoomOut</option><option';
                if ($meta == 'zoomIn') { echo ' selected="selected"'; }
                echo ' value="zoomIn">zoomIn</option><option';
                if ($meta == 'bounceInUp') { echo ' selected="selected"'; }
                echo ' value="bounceInUp">bounceInUp</option><option';
                if ($meta == 'bounceInRight') { echo ' selected="selected"'; }
                echo ' value="bounceInRight">bounceInRight</option><option';
                if ($meta == 'bounceInDown') { echo ' selected="selected"'; }
                echo ' value="bounceInDown">bounceInDown</option><option';
                if ($meta == 'bounceInLeft') { echo ' selected="selected"'; }
                echo ' value="bounceInLeft">bounceInLeft</option><option';
                if ($meta == 'pageRight') { echo ' selected="selected"'; }
                echo ' value="pageRight">pageRight</option><option';
                if ($meta == 'pageRightBack') { echo ' selected="selected"'; }
                echo ' value="pageRightBack">pageRightBack</option><option';
                if ($meta == 'pageLeft') { echo ' selected="selected"'; }
                echo ' value="pageLeft">pageLeft</option><option';
                if ($meta == 'pageLeftBack') { echo ' selected="selected"'; }
                echo ' value="pageLeftBack">pageLeftBack</option><option';
                if ($meta == 'pageBottomBack') { echo ' selected="selected"'; }
                echo ' value="pageBottomBack">pageBottomBack</option><option';
                if ($meta == 'pageTopBack') { echo ' selected="selected"'; }
                echo ' value="pageTopBack">pageTopBack</option><option';                
                if ($meta == 'tinDown') { echo ' selected="selected"'; }
                echo ' value="tinDown">tinDown</option><option';
                if ($meta == 'tinUp') { echo ' selected="selected"'; }
                echo ' value="tinUp">tinUp</option><option';
                if ($meta == 'tinRight') { echo ' selected="selected"'; }
                echo ' value="tinRight">tinRight</option><option';
                if ($meta == 'tinLeft') { echo ' selected="selected"'; }
                echo ' value="tinLeft">tinLeft</option>';
                break;
            }
            echo    '</select>';
            ?>
<?php
        }

    } 

function dysania_add_dysaniatitle_meta_box() {
    global $dysaniatitle_metabox;        
    foreach($dysaniatitle_metabox['page'] as $page) {
        add_meta_box($dysaniatitle_metabox['id'], $dysaniatitle_metabox['title'], 'dysania_show_dysaniatitle_box', $page, 'normal', 'default', $dysaniatitle_metabox);
    }
}

function dysania_show_dysaniatitle_box()  {
    global $post;
    global $dysaniatitle_metabox;
    global $dysania_prefix;
    global $wp_version;
    echo '<input type="hidden" name="dysania_dysaniatitle_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
    foreach ($dysaniatitle_metabox['fields'] as $field) {
        $meta = get_post_meta($post->ID, $field['id'], true);
        switch ($field['type']) {
            case 'text':
            echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : @$field['std'], '" style="width:100%" /><br/>', '', stripslashes($field['desc']);    
            break;
        }
    }
}


function dysania_add_dysaniaslide_meta_box() {
    global $dysaniaslide_metabox;        
    foreach($dysaniaslide_metabox['page'] as $page) {
        add_meta_box($dysaniaslide_metabox['id'], $dysaniaslide_metabox['title'], 'dysania_show_dysaniaslide_box', $page, 'normal', 'default', $dysaniaslide_metabox);
    }
}

function dysania_show_dysaniaslide_box()  {
    global $post;
    global $dysaniaslide_metabox;
    global $dysania_prefix;
    global $wp_version;
    echo '<input type="hidden" name="dysania_dysaniaslide_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
    foreach ($dysaniaslide_metabox['fields'] as $field) {
        $meta = get_post_meta($post->ID, $field['id'], true);
        switch ($field['type']) {
            case 'text':
            echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : @$field['std'], '" style="width:100%" /><br/>', '', stripslashes($field['desc']);
            echo '<input id="dysania_featured_image_button" class="button" type="button" value="Upload Image" />';    
            echo '<script type="text/javascript">
jQuery(document).ready(function($){ 
    var custom_uploader; 
    $("#dysania_featured_image_button").click(function(e) { 
        e.preventDefault();
        if (custom_uploader) {
            custom_uploader.open();
            return;
        }
        custom_uploader = wp.media.frames.file_frame = wp.media({
            title: "Choose Image",
            button: {
                text: "Choose Image"
            },
            multiple: false
        });
        custom_uploader.on("select", function() {
            attachment = custom_uploader.state().get("selection").first().toJSON();
            $("#', $field['id'], '").val(attachment.url);
        });
        custom_uploader.open(); 
    }); 
});    
</script>  ';            
            break;
        }
    }
}

function dysania_add_slidelink_2_meta_box() {   
        global $slidelink_2_metabox;            
        foreach($slidelink_2_metabox['page'] as $page) {
 add_meta_box($slidelink_2_metabox['id'], $slidelink_2_metabox['title'], 'dysania_show_slidelink_2_box', $page, 'normal', 'default', $slidelink_2_metabox);
        }
    }
    function dysania_show_slidelink_2_box()  {
        global $post;
        global $slidelink_2_metabox;
        global $dysania_prefix;
        global $wp_version;
        echo '<input type="hidden" name="dysania_slidelink_2_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />'; 
        foreach ($slidelink_2_metabox['fields'] as $field) {
            $meta = get_post_meta($post->ID, $field['id'], true);
            switch ($field['type']) {
                case 'text':
                    echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : @$field['std'], '" size="30" style="width:100%" />', '', stripslashes($field['desc']);
                    break;
            }
        }
    }

function dysania_add_slidelink_3_meta_box() {   
        global $slidelink_3_metabox;            
        foreach($slidelink_3_metabox['page'] as $page) {
 add_meta_box($slidelink_3_metabox['id'], $slidelink_3_metabox['title'], 'dysania_show_slidelink_3_box', $page, 'normal', 'default', $slidelink_3_metabox);
        }
    }
    function dysania_show_slidelink_3_box()  {
        global $post;
        global $slidelink_3_metabox;
        global $dysania_prefix;
        global $wp_version;
        echo '<input type="hidden" name="dysania_slidelink_3_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />'; 
        foreach ($slidelink_3_metabox['fields'] as $field) {
            $meta = get_post_meta($post->ID, $field['id'], true);
            switch ($field['type']) {
                case 'text':
                    echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : @$field['std'], '" size="30" style="width:100%" />', '', stripslashes($field['desc']);
                    echo '<label>Example embed video links;</label>';
                    echo '<br/><br/>http://www.youtube.com/embed/1iIZeIy7TqM';
                    echo '<br/>http://player.vimeo.com/video/24535181';
                    break;
            }
        }
    }  

add_action('save_post', 'dysania_dysaniaslide_save');
function dysania_dysaniaslide_save($post_id) {
    global $post;
    global $dysaniatitle_metabox;
    global $dysaniaslide_metabox;
    global $slidelink_2_metabox;
    global $slidelink_3_metabox;
    global $dysanianimation_metabox;
    global $dysanianimation2_metabox;
    if (!wp_verify_nonce(@$_POST['dysania_dysaniaslide_meta_box_nonce'], basename(__FILE__))) {
        return $post_id;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }
    if ('page' == $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id)) {
            return $post_id;
        }
    } elseif (!current_user_can('edit_post', $post_id)) {
        return $post_id;
    }
    foreach ($dysaniatitle_metabox['fields'] as $field) {
        $old = get_post_meta($post_id, $field['id'], true);
        $new = $_POST[$field['id']];
        if ($new && $new != $old) {
            if($field['type'] == 'date') {
                $new = dysania_format_date($new);
                update_post_meta($post_id, $field['id'], $new);
            } else {
                if(is_string($new)) {
                    $new = $new;
                } 
                update_post_meta($post_id, $field['id'], $new);
            }
        } elseif ('' == $new && $old) {
            delete_post_meta($post_id, $field['id'], $old);
        }
    }
    foreach ($dysaniaslide_metabox['fields'] as $field) {
        $old = get_post_meta($post_id, $field['id'], true);
        $new = $_POST[$field['id']];
        if ($new && $new != $old) {
            if($field['type'] == 'date') {
                $new = dysania_format_date($new);
                update_post_meta($post_id, $field['id'], $new);
            } else {
                if(is_string($new)) {
                    $new = $new;
                } 
                update_post_meta($post_id, $field['id'], $new);
            }
        } elseif ('' == $new && $old) {
            delete_post_meta($post_id, $field['id'], $old);
        }
    }
    foreach ($dysanianimation_metabox['fields'] as $field) {
         
            $old = get_post_meta($post_id, $field['id'], true);
            $new = $_POST[$field['id']];
             
            if ($new && $new != $old) {
                if($field['type'] == 'date') {
                    $new = dysania_format_date($new);
                    update_post_meta($post_id, $field['id'], $new);
                } else {
                    if(is_string($new)) {
                        $new = $new;
                    } 
                    update_post_meta($post_id, $field['id'], $new);
                     
                     
                }
            } elseif ('' == $new && $old) {
                delete_post_meta($post_id, $field['id'], $old);
            }
        }
    foreach ($dysanianimation2_metabox['fields'] as $field) {
         
            $old = get_post_meta($post_id, $field['id'], true);
            $new = $_POST[$field['id']];
             
            if ($new && $new != $old) {
                if($field['type'] == 'date') {
                    $new = dysania_format_date($new);
                    update_post_meta($post_id, $field['id'], $new);
                } else {
                    if(is_string($new)) {
                        $new = $new;
                    } 
                    update_post_meta($post_id, $field['id'], $new);
                     
                     
                }
            } elseif ('' == $new && $old) {
                delete_post_meta($post_id, $field['id'], $old);
            }
        }       
    foreach ($slidelink_2_metabox['fields'] as $field) {
         
            $old = get_post_meta($post_id, $field['id'], true);
            $new = $_POST[$field['id']];
             
            if ($new && $new != $old) {
                if($field['type'] == 'date') {
                    $new = dysania_format_date($new);
                    update_post_meta($post_id, $field['id'], $new);
                } else {
                    if(is_string($new)) {
                        $new = $new;
                    } 
                    update_post_meta($post_id, $field['id'], $new);                    
                }
            } elseif ('' == $new && $old) {
                delete_post_meta($post_id, $field['id'], $old);
            }
        }
    foreach ($slidelink_3_metabox['fields'] as $field) {
         
            $old = get_post_meta($post_id, $field['id'], true);
            $new = $_POST[$field['id']];
             
            if ($new && $new != $old) {
                if($field['type'] == 'date') {
                    $new = dysania_format_date($new);
                    update_post_meta($post_id, $field['id'], $new);
                } else {
                    if(is_string($new)) {
                        $new = $new;
                    } 
                    update_post_meta($post_id, $field['id'], $new);                    
                }
            } elseif ('' == $new && $old) {
                delete_post_meta($post_id, $field['id'], $old);
            }
        }
}

function dysania_image_box() {
    remove_meta_box( 'postimagediv', 'dysaniaslides', 'side' );
    add_meta_box('postimagediv', __('Slider Image', 'dysaniasliders'), 'post_thumbnail_meta_box', 'dysaniaslides', 'normal', 'high');
}
?>