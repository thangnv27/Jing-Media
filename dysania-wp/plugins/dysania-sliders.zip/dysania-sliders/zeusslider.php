<?php

$autoplay = get_option('dysania_sliderautoplay');
$autoplayspeed = get_option('dysania_sliderautoplayspeed');
$zeusheight = get_option('dysania_zeusheight');
		
$args = array(
    'post_type' => 'dysaniaslides',
    'posts_per_page'  => 99
);

$c = 0;
$class = '';
$the_query = new WP_Query( $args );
$count = 1;
if ( $the_query->have_posts() ) {
    
?>
            <div id="zeusslider">
                <div class="zeus-slider zeus-default">
<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
<?php $imageurl = wp_get_attachment_url( get_post_thumbnail_id(get_the_id()) ); ?>
<?php $slideurl = get_post_meta( get_the_id(), 'dysaniaslide_slideurl', true ); ?>
<?php $videourl = get_post_meta( get_the_id(), 'dysaniaslide_videourl', true ); ?>                     
<?php $secondimage = get_post_meta( get_the_id(), 'dysaniaslide_url', true ); ?>
<?php $animation = get_post_meta( get_the_id(), 'dysanianimation', true ); ?> 
<?php $secondanimation = get_post_meta( get_the_id(), 'dysanianimation2', true ); ?>
<?php $secondtitle = get_post_meta( get_the_id(), 'dysaniaslide_title', true ); ?>                     
                    <div class="zeus-block">
<?php 
    if (!empty($videourl)) { 
?>
                        <div class="zeus-slide s-100">
                            <iframe src="<?php echo $videourl; ?>"></iframe>
                        </div>
<?php 
    }
    else if(!empty($secondimage)) { ?>                        
                        <div class="zeus-slide s-50">
                            <?php 
    if(!empty($slideurl)) { echo '<a href="' . $slideurl . '">'; }
    echo '<img src="' . $imageurl . '" data-effect="' . $animation . '" alt="" />'; 
    if(!empty($slideurl)) { echo '</a>'; }
                            ?>
                            <div class="zeus-text-left bounceInUp"><?php the_title(); ?></div>
                        </div>
                        <div class="zeus-slide s-50">
                            <?php 
    if(!empty($slideurl)) { echo '<a href="' . $slideurl . '">'; }
    echo '<img src="' . $secondimage . '" data-effect="' . $secondanimation . '" alt="" />'; 
    if(!empty($slideurl)) { echo '</a>'; }
                            ?>
                            <?php if(!empty($secondtitle)) { echo '<div class="zeus-text-right bounceInDown">' . $secondtitle . '</div>'; } ?>
                        </div>
<?php } else { ?>
                        <div class="zeus-slide s-100">
                            <?php if(!empty($slideurl)) { echo '<a href="' . $slideurl . '">'; } ?>
                            <img src="<?php echo $imageurl; ?>" data-effect="<?php echo $animation; ?>" alt="" />
                            <?php if(!empty($slideurl)) { echo '</a>'; } ?>
                        </div>
                        <?php if(!empty($secondtitle)) { echo '<div class="zeus-info">' . $secondtitle . '</div>'; } ?>
<?php } ?>    
                    </div>
                    <?php endwhile; ?>
                    <div class="clear"></div>
                    <div class="next-block"></div>
                    <div class="prev-block"></div>
                </div>
            </div>
<script type="text/javascript">
            jQuery(window).load(function() {
                jQuery("#zeusslider").zeusslider({
                    autoplay: <?php if ($autoplay == "true") { echo 'false'; } else { echo 'true'; } ?>,
                    duration: <?php if (!empty($autoplayspeed)) { echo $autoplayspeed; } else { echo '5'; } ?>000,
                    sliderheight: <?php if (!empty($zeusheight)) { echo $zeusheight; } else { echo '2.5'; } ?>,
                    onslidechange: function() {
                        jQuery("#zeusslider").find('.zeus-text-right').addClass('bounceInDown');
                        jQuery("#zeusslider").find('.zeus-text-left').addClass('bounceInUp');
                        setTimeout(function() {
                            jQuery("#zeusslider").find('.zeus-text-right').removeClass('bounceInDown');
                            jQuery("#zeusslider").find('.zeus-text-left').removeClass('bounceInUp');
                        }, 1000);
                    }
                });
            });
        </script>
<?php }
wp_reset_postdata();
?>