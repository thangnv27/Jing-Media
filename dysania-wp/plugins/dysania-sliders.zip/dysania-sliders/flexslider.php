<?php

$autoplay = get_option('dysania_sliderautoplay');
$autoplayspeed = get_option('dysania_sliderautoplayspeed');
		
$args = array(
    'post_type' => 'dysaniaflex',
    'posts_per_page'  => 99
);

$c = 0;
$class = '';
$the_query = new WP_Query( $args );
$count = 1;
if ( $the_query->have_posts() ) {
    
?>

<div class="flex-wrapper">
                <div class="flexslider" id="slider">
                    <ul class="slides">
                        <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
                        <?php $imageurl = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_id() ), 'flexslider-image' ) ?>
                        <?php $slideurl = get_post_meta( get_the_id(), 'dysaniaflexurl', true ); ?>    
                        <li>
                            <?php if (get_the_title()) { ?>
                            <h3 class="flex-title-<?php if ($count % 2 == 0) { echo 'right'; } else { echo 'left'; } ?>"><?php the_title(); ?></h3>
                            <?php } ?>
                            <?php 
    if(!empty($slideurl)) { echo '<a href="' . $slideurl . '">'; }
    echo '<img src="' . $imageurl['0'] . '" alt="" />'; 
    if(!empty($slideurl)) { echo '</a>'; }
                            ?>
                        </li>
                        <?php $count++; ?>
                        <?php endwhile; ?>
                    </ul>
                </div>
            </div>
<script type="text/javascript">
(function ($) {    
$(window).load(function () {

   $('#slider').flexslider({
        controlNav: false,
        pauseOnHover: true,
        animation: "slide",
        slideshow: <?php if ($autoplay == "true") { echo 'false'; } else { echo 'true'; } ?>,
        slideshowSpeed: <?php if (!empty($autoplayspeed)) { echo $autoplayspeed; } else { echo '5'; } ?>000,

        start: function (slider) {
            slider.removeClass('loading');
            $('.flex-title-left').animate({ left: 0 }, 300);
            $('.flex-title-right').animate({ right: 0 }, 300);

        },
        before: function (slider) {
            $('.flex-title-left').animate({ left: 100, opacity: 0 }, 300);
            $('.flex-title-right').animate({ right: 100, opacity: 0 }, 300);
        },
        after: function (slider) {
            $('.flex-title-left').animate({ left: 0, opacity: 0.9 }, 300);
            $('.flex-title-right').animate({ right: 0, opacity: 0.9 }, 300);
        }
    });

    $('.flex-wrapper').find('.flex-direction-nav li a').animate({ opacity: 0 }, 0);

    $('.flex-wrapper').hover(function () {

        $(this).find('.flex-direction-nav li a').animate({ opacity: 1 }, 300);

    }, function () {

        $(this).find('.flex-direction-nav li a').animate({ opacity: 0 }, 300);

    });
});
}(jQuery));    
</script>

<?php }
wp_reset_postdata();
?>