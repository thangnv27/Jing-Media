<?php
function register_dysaniaflexslides_posttype() {
    $labels = array(
        'name'              => __( 'Flex Slider', 'dysaniasliders' ),
        'singular_name'     => __( 'slide', 'dysaniasliders' ),
        'add_new'           => __( 'Add New Slide', 'dysaniasliders' ),
        'add_new_item'      => __( 'Add New Slide', 'dysaniasliders' ),
        'edit_item'         => __( 'Edit Slide', 'dysaniasliders' ),
        'new_item'          => __( 'New Slide', 'dysaniasliders' ),
        'view_item'         => __( 'View Slide', 'dysaniasliders' ),
        'search_items'      => __( 'Search Slides', 'dysaniasliders' ),
        'not_found'         => __( 'No slide found', 'dysaniasliders' ),
        'not_found_in_trash'=> __( 'No slide found in Trash', 'dysaniasliders' ),
        'parent_item_colon' => __( 'Parent slides:', 'dysaniasliders' ),
        'menu_name'         => __( 'Flex Slider', 'dysaniasliders' )
    );

    $taxonomies = array();
 
    $supports = array('title','thumbnail');
 
    $post_type_args = array(
        'labels'            => $labels,
        'singular_label'    => __('slide', 'dysaniasliders'),
        'public'            => true,
        'exclude_from_search' => true,
        'show_ui'           => true,
        'publicly_queryable'=> true,
        'query_var'         => true,
        'capability_type'   => 'post',
        'has_archive'       => false,
        'hierarchical'      => false,
        'rewrite'           => array( 'slug' => 'dysaniaflex', 'with_front' => false ),
        'supports'          => $supports,
        'menu_position'     => 99,
        'menu_icon'         => 'dashicons-camera',
        'taxonomies'        => $taxonomies
    );
    register_post_type('dysaniaflex',$post_type_args);
}
add_action('init', 'register_dysaniaflexslides_posttype');

$flexslidelink_metabox = array( 
        'id' => 'slidelink',
        'title' => 'Link (Optional)',
        'page' => array('dysaniaflex'),
        'context' => 'normal',
        'priority' => 'default',
        'fields' => array(                     
                    array(
                        'name'          => 'URL:',
                        'desc'          => '',
                        'id'                => 'dysaniaflexurl',
                        'class'             => 'dysaniaflexurl',
                        'type'          => 'text',
                        'rich_editor'   => 0,            
                        'max'           => 0             
                    ),
                    )
    );

add_action('do_meta_boxes', 'dysaniaflex_image_box');
add_action('admin_menu', 'dysania_add_flexslidelink_meta_box');

function dysania_add_flexslidelink_meta_box() {   
        global $flexslidelink_metabox;            
        foreach($flexslidelink_metabox['page'] as $page) {
 add_meta_box($flexslidelink_metabox['id'], $flexslidelink_metabox['title'], 'dysania_show_flexslidelink_box', $page, 'normal', 'default', $flexslidelink_metabox);
        }
    }
    function dysania_show_flexslidelink_box()  {
        global $post;
        global $flexslidelink_metabox;
        global $dysania_prefix;
        global $wp_version;
        echo '<input type="hidden" name="dysania_flexslidelink_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />'; 
        foreach ($flexslidelink_metabox['fields'] as $field) {
            $meta = get_post_meta($post->ID, $field['id'], true);
            switch ($field['type']) {
                case 'text':
                    echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : @$field['std'], '" size="30" style="width:100%" />', '', stripslashes($field['desc']);
                    break;
            }
        }
    }  

add_action('save_post', 'dysania_flexslidelink_save');
function dysania_flexslidelink_save($post_id) {
    global $post;
    global $flexslidelink_metabox;
    if (!wp_verify_nonce(@$_POST['dysania_flexslidelink_meta_box_nonce'], basename(__FILE__))) {
        return $post_id;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }
    if ('page' == $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id)) {
            return $post_id;
        }
    } elseif (!current_user_can('edit_post', $post_id)) {
        return $post_id;
    }
    foreach ($flexslidelink_metabox['fields'] as $field) {
         
            $old = get_post_meta($post_id, $field['id'], true);
            $new = $_POST[$field['id']];
             
            if ($new && $new != $old) {
                if($field['type'] == 'date') {
                    $new = dysania_format_date($new);
                    update_post_meta($post_id, $field['id'], $new);
                } else {
                    if(is_string($new)) {
                        $new = $new;
                    } 
                    update_post_meta($post_id, $field['id'], $new);                    
                }
            } elseif ('' == $new && $old) {
                delete_post_meta($post_id, $field['id'], $old);
            }
        }
}

function dysaniaflex_image_box() {
    remove_meta_box( 'postimagediv', 'dysaniaflex', 'side' );
    add_meta_box('postimagediv', __('Slider Image', 'dysaniasliders'), 'post_thumbnail_meta_box', 'dysaniaflex', 'normal', 'high');
}
?>