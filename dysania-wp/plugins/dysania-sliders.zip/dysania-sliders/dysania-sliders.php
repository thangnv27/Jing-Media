<?php
/**
 * Plugin Name: Dysania Sliders
 * Plugin URI: http://themeforest.net/user/egemenerd/portfolio
 * Description: Dysania Sliders
 * Version: 1.0
 * Author: Egemenerd
 * Author URI: http://themeforest.net/user/egemenerd
 * License: http://themeforest.net/licenses
 */

add_action( 'init', 'dysaniaslidersdomain' );

function dysaniaslidersdomain() {
	load_plugin_textdomain( 'dysaniasliders', false, 'dysania-sliders/languages' );
}

if ( function_exists( 'add_theme_support' ) ) { 
    add_image_size( 'flexslider-image', 1024, 350, true);
    add_filter('image_size_names_choose', 'dysania_slider_sizes');
}

if ( ! function_exists( 'dysania_slider_sizes' ) ) {
function dysania_slider_sizes($slidersizes) {
    $slideraddsizes = array(
        "flexslider-image" => __( 'Flexslider Image', 'dysaniasliders')
    );
    $slidernewsizes = array_merge($slidersizes, $slideraddsizes);
    return $slidernewsizes;
}
}

function dysania_slider_scripts(){
    wp_enqueue_style('dysania_flexslider_style', plugin_dir_url( __FILE__ ) . 'css/flexslider.css', true, '1.0');
    wp_enqueue_style('dysania_zeusslider_style', plugin_dir_url( __FILE__ ) . 'css/zeusslider.css', true, '1.0');
    wp_enqueue_style('dysania_zeusanimations_style', plugin_dir_url( __FILE__ ) . 'css/zeusanimations.css', true, '1.0');
    wp_register_script('dysania_zeusslider',plugin_dir_url( __FILE__ ).'js/zeusslider.js','','',true);
    wp_register_script('dysania_flexslider',plugin_dir_url( __FILE__ ).'js/jquery.flexslider.js','','',true);
    wp_enqueue_script('dysania_zeusslider');
    wp_enqueue_script('dysania_flexslider');
}
add_action('wp_enqueue_scripts','dysania_slider_scripts');

include('slider_post_type.php');
include('flexslider_post_type.php');

function dysania_flexslider_template(){
include('flexslider.php');
}

function dysania_zeusslider_template(){
include('zeusslider.php');
}


?>
